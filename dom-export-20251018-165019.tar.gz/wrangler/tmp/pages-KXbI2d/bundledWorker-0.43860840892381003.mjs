var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../node_modules/unenv/dist/runtime/_internal/utils.mjs
// @__NO_SIDE_EFFECTS__
function createNotImplementedError(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented(name) {
  const fn = /* @__PURE__ */ __name(() => {
    throw /* @__PURE__ */ createNotImplementedError(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass, "notImplementedClass");

// ../node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry = class {
  static {
    __name(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark = class PerformanceMark2 extends PerformanceEntry {
  static {
    __name(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance = class {
  static {
    __name(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw createNotImplementedError("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin) {
      return _performanceNow();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw createNotImplementedError("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver = class {
  static {
    __name(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw createNotImplementedError("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw createNotImplementedError("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();

// ../node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;

// ../node_modules/unenv/dist/runtime/node/console.mjs
import { Writable } from "node:stream";

// ../node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {
}, { __unenv__: true });

// ../node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _ignoreErrors = true;
var _stderr = new Writable();
var _stdout = new Writable();
var log = _console?.log ?? noop_default;
var info = _console?.info ?? log;
var trace = _console?.trace ?? info;
var debug = _console?.debug ?? log;
var table = _console?.table ?? log;
var error = _console?.error ?? log;
var warn = _console?.warn ?? error;
var createTask = _console?.createTask ?? /* @__PURE__ */ notImplemented("console.createTask");
var clear = _console?.clear ?? noop_default;
var count = _console?.count ?? noop_default;
var countReset = _console?.countReset ?? noop_default;
var dir = _console?.dir ?? noop_default;
var dirxml = _console?.dirxml ?? noop_default;
var group = _console?.group ?? noop_default;
var groupEnd = _console?.groupEnd ?? noop_default;
var groupCollapsed = _console?.groupCollapsed ?? noop_default;
var profile = _console?.profile ?? noop_default;
var profileEnd = _console?.profileEnd ?? noop_default;
var time = _console?.time ?? noop_default;
var timeEnd = _console?.timeEnd ?? noop_default;
var timeLog = _console?.timeLog ?? noop_default;
var timeStamp = _console?.timeStamp ?? noop_default;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;

// ../node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var {
  assert,
  clear: clear2,
  // @ts-expect-error undocumented public API
  context,
  count: count2,
  countReset: countReset2,
  // @ts-expect-error undocumented public API
  createTask: createTask2,
  debug: debug2,
  dir: dir2,
  dirxml: dirxml2,
  error: error2,
  group: group2,
  groupCollapsed: groupCollapsed2,
  groupEnd: groupEnd2,
  info: info2,
  log: log2,
  profile: profile2,
  profileEnd: profileEnd2,
  table: table2,
  time: time2,
  timeEnd: timeEnd2,
  timeLog: timeLog2,
  timeStamp: timeStamp2,
  trace: trace2,
  warn: warn2
} = workerdConsole;
Object.assign(workerdConsole, {
  Console,
  _ignoreErrors,
  _stderr,
  _stderrErrorHandler,
  _stdout,
  _stdoutErrorHandler,
  _times
});
var console_default = workerdConsole;

// ../node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-console
globalThis.console = console_default;

// ../node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name(function hrtime2(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime"), { bigint: /* @__PURE__ */ __name(function bigint() {
  return BigInt(Date.now() * 1e6);
}, "bigint") });

// ../node_modules/unenv/dist/runtime/node/internal/process/process.mjs
import { EventEmitter } from "node:events";

// ../node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
var ReadStream = class {
  static {
    __name(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};

// ../node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
var WriteStream = class {
  static {
    __name(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir3, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x2, y2, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env2) {
    return 1;
  }
  hasColors(count3, env2) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};

// ../node_modules/unenv/dist/runtime/node/internal/process/node-version.mjs
var NODE_VERSION = "22.14.0";

// ../node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class _Process extends EventEmitter {
  static {
    __name(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd2) {
    this.#cwd = cwd2;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION}`;
  }
  get versions() {
    return { node: NODE_VERSION };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw createNotImplementedError("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw createNotImplementedError("process.getActiveResourcesInfo");
  }
  exit() {
    throw createNotImplementedError("process.exit");
  }
  reallyExit() {
    throw createNotImplementedError("process.reallyExit");
  }
  kill() {
    throw createNotImplementedError("process.kill");
  }
  abort() {
    throw createNotImplementedError("process.abort");
  }
  dlopen() {
    throw createNotImplementedError("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw createNotImplementedError("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw createNotImplementedError("process.loadEnvFile");
  }
  disconnect() {
    throw createNotImplementedError("process.disconnect");
  }
  cpuUsage() {
    throw createNotImplementedError("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw createNotImplementedError("process.initgroups");
  }
  openStdin() {
    throw createNotImplementedError("process.openStdin");
  }
  assert() {
    throw createNotImplementedError("process.assert");
  }
  binding() {
    throw createNotImplementedError("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};

// ../node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var workerdProcess = getBuiltinModule("node:process");
var isWorkerdProcessV2 = globalThis.Cloudflare.compatibilityFlags.enable_nodejs_process_v2;
var unenvProcess = new Process({
  env: globalProcess.env,
  // `hrtime` is only available from workerd process v2
  hrtime: isWorkerdProcessV2 ? workerdProcess.hrtime : hrtime,
  // `nextTick` is available from workerd process v1
  nextTick: workerdProcess.nextTick
});
var { exit, features, platform } = workerdProcess;
var {
  // Always implemented by workerd
  env,
  // Only implemented in workerd v2
  hrtime: hrtime3,
  // Always implemented by workerd
  nextTick
} = unenvProcess;
var {
  _channel,
  _disconnect,
  _events,
  _eventsCount,
  _handleQueue,
  _maxListeners,
  _pendingMessage,
  _send,
  assert: assert2,
  disconnect,
  mainModule
} = unenvProcess;
var {
  // @ts-expect-error `_debugEnd` is missing typings
  _debugEnd,
  // @ts-expect-error `_debugProcess` is missing typings
  _debugProcess,
  // @ts-expect-error `_exiting` is missing typings
  _exiting,
  // @ts-expect-error `_fatalException` is missing typings
  _fatalException,
  // @ts-expect-error `_getActiveHandles` is missing typings
  _getActiveHandles,
  // @ts-expect-error `_getActiveRequests` is missing typings
  _getActiveRequests,
  // @ts-expect-error `_kill` is missing typings
  _kill,
  // @ts-expect-error `_linkedBinding` is missing typings
  _linkedBinding,
  // @ts-expect-error `_preload_modules` is missing typings
  _preload_modules,
  // @ts-expect-error `_rawDebug` is missing typings
  _rawDebug,
  // @ts-expect-error `_startProfilerIdleNotifier` is missing typings
  _startProfilerIdleNotifier,
  // @ts-expect-error `_stopProfilerIdleNotifier` is missing typings
  _stopProfilerIdleNotifier,
  // @ts-expect-error `_tickCallback` is missing typings
  _tickCallback,
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  arch,
  argv,
  argv0,
  availableMemory,
  // @ts-expect-error `binding` is missing typings
  binding,
  channel,
  chdir,
  config,
  connected,
  constrainedMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  // @ts-expect-error `domain` is missing typings
  domain,
  emit,
  emitWarning,
  eventNames,
  execArgv,
  execPath,
  exitCode,
  finalization,
  getActiveResourcesInfo,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getMaxListeners,
  getuid,
  hasUncaughtExceptionCaptureCallback,
  // @ts-expect-error `initgroups` is missing typings
  initgroups,
  kill,
  listenerCount,
  listeners,
  loadEnvFile,
  memoryUsage,
  // @ts-expect-error `moduleLoadList` is missing typings
  moduleLoadList,
  off,
  on,
  once,
  // @ts-expect-error `openStdin` is missing typings
  openStdin,
  permission,
  pid,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  // @ts-expect-error `reallyExit` is missing typings
  reallyExit,
  ref,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  send,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setMaxListeners,
  setSourceMapsEnabled,
  setuid,
  setUncaughtExceptionCaptureCallback,
  sourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  throwDeprecation,
  title,
  traceDeprecation,
  umask,
  unref,
  uptime,
  version,
  versions
} = isWorkerdProcessV2 ? workerdProcess : unenvProcess;
var _process = {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exit,
  finalization,
  features,
  getBuiltinModule,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  nextTick,
  on,
  off,
  once,
  pid,
  platform,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  // @ts-expect-error old API
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
};
var process_default = _process;

// ../node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-process
globalThis.process = process_default;

// _worker.js
var kt = Object.defineProperty;
var Ze = /* @__PURE__ */ __name((e) => {
  throw TypeError(e);
}, "Ze");
var qt = /* @__PURE__ */ __name((e, t, r) => t in e ? kt(e, t, { enumerable: true, configurable: true, writable: true, value: r }) : e[t] = r, "qt");
var b = /* @__PURE__ */ __name((e, t, r) => qt(e, typeof t != "symbol" ? t + "" : t, r), "b");
var ze = /* @__PURE__ */ __name((e, t, r) => t.has(e) || Ze("Cannot " + r), "ze");
var u = /* @__PURE__ */ __name((e, t, r) => (ze(e, t, "read from private field"), r ? r.call(e) : t.get(e)), "u");
var y = /* @__PURE__ */ __name((e, t, r) => t.has(e) ? Ze("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, r), "y");
var g = /* @__PURE__ */ __name((e, t, r, a) => (ze(e, t, "write to private field"), a ? a.call(e, r) : t.set(e, r), r), "g");
var w = /* @__PURE__ */ __name((e, t, r) => (ze(e, t, "access private method"), r), "w");
var et = /* @__PURE__ */ __name((e, t, r, a) => ({ set _(s) {
  g(e, t, s, r);
}, get _() {
  return u(e, t, a);
} }), "et");
var tt = /* @__PURE__ */ __name((e, t, r) => (a, s) => {
  let i = -1;
  return n(0);
  async function n(o) {
    if (o <= i) throw new Error("next() called multiple times");
    i = o;
    let d, l = false, c;
    if (e[o] ? (c = e[o][0][0], a.req.routeIndex = o) : c = o === e.length && s || void 0, c) try {
      d = await c(a, () => n(o + 1));
    } catch (p) {
      if (p instanceof Error && t) a.error = p, d = await t(p, a), l = true;
      else throw p;
    }
    else a.finalized === false && r && (d = await r(a));
    return d && (a.finalized === false || l) && (a.res = d), a;
  }
  __name(n, "n");
}, "tt");
var Pt = Symbol();
var Ut = /* @__PURE__ */ __name(async (e, t = /* @__PURE__ */ Object.create(null)) => {
  const { all: r = false, dot: a = false } = t, i = (e instanceof Et ? e.raw.headers : e.headers).get("Content-Type");
  return i != null && i.startsWith("multipart/form-data") || i != null && i.startsWith("application/x-www-form-urlencoded") ? $t(e, { all: r, dot: a }) : {};
}, "Ut");
async function $t(e, t) {
  const r = await e.formData();
  return r ? Wt(r, t) : {};
}
__name($t, "$t");
function Wt(e, t) {
  const r = /* @__PURE__ */ Object.create(null);
  return e.forEach((a, s) => {
    t.all || s.endsWith("[]") ? Jt(r, s, a) : r[s] = a;
  }), t.dot && Object.entries(r).forEach(([a, s]) => {
    a.includes(".") && (Vt(r, a, s), delete r[a]);
  }), r;
}
__name(Wt, "Wt");
var Jt = /* @__PURE__ */ __name((e, t, r) => {
  e[t] !== void 0 ? Array.isArray(e[t]) ? e[t].push(r) : e[t] = [e[t], r] : t.endsWith("[]") ? e[t] = [r] : e[t] = r;
}, "Jt");
var Vt = /* @__PURE__ */ __name((e, t, r) => {
  let a = e;
  const s = t.split(".");
  s.forEach((i, n) => {
    n === s.length - 1 ? a[i] = r : ((!a[i] || typeof a[i] != "object" || Array.isArray(a[i]) || a[i] instanceof File) && (a[i] = /* @__PURE__ */ Object.create(null)), a = a[i]);
  });
}, "Vt");
var ht = /* @__PURE__ */ __name((e) => {
  const t = e.split("/");
  return t[0] === "" && t.shift(), t;
}, "ht");
var zt = /* @__PURE__ */ __name((e) => {
  const { groups: t, path: r } = Yt(e), a = ht(r);
  return Gt(a, t);
}, "zt");
var Yt = /* @__PURE__ */ __name((e) => {
  const t = [];
  return e = e.replace(/\{[^}]+\}/g, (r, a) => {
    const s = `@${a}`;
    return t.push([s, r]), s;
  }), { groups: t, path: e };
}, "Yt");
var Gt = /* @__PURE__ */ __name((e, t) => {
  for (let r = t.length - 1; r >= 0; r--) {
    const [a] = t[r];
    for (let s = e.length - 1; s >= 0; s--) if (e[s].includes(a)) {
      e[s] = e[s].replace(a, t[r][1]);
      break;
    }
  }
  return e;
}, "Gt");
var Fe = {};
var Kt = /* @__PURE__ */ __name((e, t) => {
  if (e === "*") return "*";
  const r = e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (r) {
    const a = `${e}#${t}`;
    return Fe[a] || (r[2] ? Fe[a] = t && t[0] !== ":" && t[0] !== "*" ? [a, r[1], new RegExp(`^${r[2]}(?=/${t})`)] : [e, r[1], new RegExp(`^${r[2]}$`)] : Fe[a] = [e, r[1], true]), Fe[a];
  }
  return null;
}, "Kt");
var Qe = /* @__PURE__ */ __name((e, t) => {
  try {
    return t(e);
  } catch {
    return e.replace(/(?:%[0-9A-Fa-f]{2})+/g, (r) => {
      try {
        return t(r);
      } catch {
        return r;
      }
    });
  }
}, "Qe");
var Xt = /* @__PURE__ */ __name((e) => Qe(e, decodeURI), "Xt");
var gt = /* @__PURE__ */ __name((e) => {
  const t = e.url, r = t.indexOf("/", t.indexOf(":") + 4);
  let a = r;
  for (; a < t.length; a++) {
    const s = t.charCodeAt(a);
    if (s === 37) {
      const i = t.indexOf("?", a), n = t.slice(r, i === -1 ? void 0 : i);
      return Xt(n.includes("%25") ? n.replace(/%25/g, "%2525") : n);
    } else if (s === 63) break;
  }
  return t.slice(r, a);
}, "gt");
var Qt = /* @__PURE__ */ __name((e) => {
  const t = gt(e);
  return t.length > 1 && t.at(-1) === "/" ? t.slice(0, -1) : t;
}, "Qt");
var fe = /* @__PURE__ */ __name((e, t, ...r) => (r.length && (t = fe(t, ...r)), `${(e == null ? void 0 : e[0]) === "/" ? "" : "/"}${e}${t === "/" ? "" : `${(e == null ? void 0 : e.at(-1)) === "/" ? "" : "/"}${(t == null ? void 0 : t[0]) === "/" ? t.slice(1) : t}`}`), "fe");
var bt = /* @__PURE__ */ __name((e) => {
  if (e.charCodeAt(e.length - 1) !== 63 || !e.includes(":")) return null;
  const t = e.split("/"), r = [];
  let a = "";
  return t.forEach((s) => {
    if (s !== "" && !/\:/.test(s)) a += "/" + s;
    else if (/\:/.test(s)) if (/\?/.test(s)) {
      r.length === 0 && a === "" ? r.push("/") : r.push(a);
      const i = s.replace("?", "");
      a += "/" + i, r.push(a);
    } else a += "/" + s;
  }), r.filter((s, i, n) => n.indexOf(s) === i);
}, "bt");
var Ye = /* @__PURE__ */ __name((e) => /[%+]/.test(e) ? (e.indexOf("+") !== -1 && (e = e.replace(/\+/g, " ")), e.indexOf("%") !== -1 ? Qe(e, yt) : e) : e, "Ye");
var vt = /* @__PURE__ */ __name((e, t, r) => {
  let a;
  if (!r && t && !/[%+]/.test(t)) {
    let n = e.indexOf(`?${t}`, 8);
    for (n === -1 && (n = e.indexOf(`&${t}`, 8)); n !== -1; ) {
      const o = e.charCodeAt(n + t.length + 1);
      if (o === 61) {
        const d = n + t.length + 2, l = e.indexOf("&", d);
        return Ye(e.slice(d, l === -1 ? void 0 : l));
      } else if (o == 38 || isNaN(o)) return "";
      n = e.indexOf(`&${t}`, n + 1);
    }
    if (a = /[%+]/.test(e), !a) return;
  }
  const s = {};
  a ?? (a = /[%+]/.test(e));
  let i = e.indexOf("?", 8);
  for (; i !== -1; ) {
    const n = e.indexOf("&", i + 1);
    let o = e.indexOf("=", i);
    o > n && n !== -1 && (o = -1);
    let d = e.slice(i + 1, o === -1 ? n === -1 ? void 0 : n : o);
    if (a && (d = Ye(d)), i = n, d === "") continue;
    let l;
    o === -1 ? l = "" : (l = e.slice(o + 1, n === -1 ? void 0 : n), a && (l = Ye(l))), r ? (s[d] && Array.isArray(s[d]) || (s[d] = []), s[d].push(l)) : s[d] ?? (s[d] = l);
  }
  return t ? s[t] : s;
}, "vt");
var Zt = vt;
var er = /* @__PURE__ */ __name((e, t) => vt(e, t, true), "er");
var yt = decodeURIComponent;
var rt = /* @__PURE__ */ __name((e) => Qe(e, yt), "rt");
var be;
var L;
var V;
var _t;
var wt;
var Ke;
var X;
var nt;
var Et = (nt = class {
  static {
    __name(this, "nt");
  }
  constructor(e, t = "/", r = [[]]) {
    y(this, V);
    b(this, "raw");
    y(this, be);
    y(this, L);
    b(this, "routeIndex", 0);
    b(this, "path");
    b(this, "bodyCache", {});
    y(this, X, (e2) => {
      const { bodyCache: t2, raw: r2 } = this, a = t2[e2];
      if (a) return a;
      const s = Object.keys(t2)[0];
      return s ? t2[s].then((i) => (s === "json" && (i = JSON.stringify(i)), new Response(i)[e2]())) : t2[e2] = r2[e2]();
    });
    this.raw = e, this.path = t, g(this, L, r), g(this, be, {});
  }
  param(e) {
    return e ? w(this, V, _t).call(this, e) : w(this, V, wt).call(this);
  }
  query(e) {
    return Zt(this.url, e);
  }
  queries(e) {
    return er(this.url, e);
  }
  header(e) {
    if (e) return this.raw.headers.get(e) ?? void 0;
    const t = {};
    return this.raw.headers.forEach((r, a) => {
      t[a] = r;
    }), t;
  }
  async parseBody(e) {
    var t;
    return (t = this.bodyCache).parsedBody ?? (t.parsedBody = await Ut(this, e));
  }
  json() {
    return u(this, X).call(this, "text").then((e) => JSON.parse(e));
  }
  text() {
    return u(this, X).call(this, "text");
  }
  arrayBuffer() {
    return u(this, X).call(this, "arrayBuffer");
  }
  blob() {
    return u(this, X).call(this, "blob");
  }
  formData() {
    return u(this, X).call(this, "formData");
  }
  addValidatedData(e, t) {
    u(this, be)[e] = t;
  }
  valid(e) {
    return u(this, be)[e];
  }
  get url() {
    return this.raw.url;
  }
  get method() {
    return this.raw.method;
  }
  get [Pt]() {
    return u(this, L);
  }
  get matchedRoutes() {
    return u(this, L)[0].map(([[, e]]) => e);
  }
  get routePath() {
    return u(this, L)[0].map(([[, e]]) => e)[this.routeIndex].path;
  }
}, be = /* @__PURE__ */ new WeakMap(), L = /* @__PURE__ */ new WeakMap(), V = /* @__PURE__ */ new WeakSet(), _t = /* @__PURE__ */ __name(function(e) {
  const t = u(this, L)[0][this.routeIndex][1][e], r = w(this, V, Ke).call(this, t);
  return r && /\%/.test(r) ? rt(r) : r;
}, "_t"), wt = /* @__PURE__ */ __name(function() {
  const e = {}, t = Object.keys(u(this, L)[0][this.routeIndex][1]);
  for (const r of t) {
    const a = w(this, V, Ke).call(this, u(this, L)[0][this.routeIndex][1][r]);
    a !== void 0 && (e[r] = /\%/.test(a) ? rt(a) : a);
  }
  return e;
}, "wt"), Ke = /* @__PURE__ */ __name(function(e) {
  return u(this, L)[1] ? u(this, L)[1][e] : e;
}, "Ke"), X = /* @__PURE__ */ new WeakMap(), nt);
var tr = { Stringify: 1 };
var xt = /* @__PURE__ */ __name(async (e, t, r, a, s) => {
  typeof e == "object" && !(e instanceof String) && (e instanceof Promise || (e = e.toString()), e instanceof Promise && (e = await e));
  const i = e.callbacks;
  return i != null && i.length ? (s ? s[0] += e : s = [e], Promise.all(i.map((o) => o({ phase: t, buffer: s, context: a }))).then((o) => Promise.all(o.filter(Boolean).map((d) => xt(d, t, false, a, s))).then(() => s[0]))) : Promise.resolve(e);
}, "xt");
var rr = "text/plain; charset=UTF-8";
var Ge = /* @__PURE__ */ __name((e, t) => ({ "Content-Type": e, ...t }), "Ge");
var je;
var Ne;
var U;
var ve;
var $;
var j;
var Ce;
var ye;
var Ee;
var ie;
var Ie;
var Ae;
var Q;
var he;
var ot;
var ar = (ot = class {
  static {
    __name(this, "ot");
  }
  constructor(e, t) {
    y(this, Q);
    y(this, je);
    y(this, Ne);
    b(this, "env", {});
    y(this, U);
    b(this, "finalized", false);
    b(this, "error");
    y(this, ve);
    y(this, $);
    y(this, j);
    y(this, Ce);
    y(this, ye);
    y(this, Ee);
    y(this, ie);
    y(this, Ie);
    y(this, Ae);
    b(this, "render", (...e2) => (u(this, ye) ?? g(this, ye, (t2) => this.html(t2)), u(this, ye).call(this, ...e2)));
    b(this, "setLayout", (e2) => g(this, Ce, e2));
    b(this, "getLayout", () => u(this, Ce));
    b(this, "setRenderer", (e2) => {
      g(this, ye, e2);
    });
    b(this, "header", (e2, t2, r) => {
      this.finalized && g(this, j, new Response(u(this, j).body, u(this, j)));
      const a = u(this, j) ? u(this, j).headers : u(this, ie) ?? g(this, ie, new Headers());
      t2 === void 0 ? a.delete(e2) : r != null && r.append ? a.append(e2, t2) : a.set(e2, t2);
    });
    b(this, "status", (e2) => {
      g(this, ve, e2);
    });
    b(this, "set", (e2, t2) => {
      u(this, U) ?? g(this, U, /* @__PURE__ */ new Map()), u(this, U).set(e2, t2);
    });
    b(this, "get", (e2) => u(this, U) ? u(this, U).get(e2) : void 0);
    b(this, "newResponse", (...e2) => w(this, Q, he).call(this, ...e2));
    b(this, "body", (e2, t2, r) => w(this, Q, he).call(this, e2, t2, r));
    b(this, "text", (e2, t2, r) => !u(this, ie) && !u(this, ve) && !t2 && !r && !this.finalized ? new Response(e2) : w(this, Q, he).call(this, e2, t2, Ge(rr, r)));
    b(this, "json", (e2, t2, r) => w(this, Q, he).call(this, JSON.stringify(e2), t2, Ge("application/json", r)));
    b(this, "html", (e2, t2, r) => {
      const a = /* @__PURE__ */ __name((s) => w(this, Q, he).call(this, s, t2, Ge("text/html; charset=UTF-8", r)), "a");
      return typeof e2 == "object" ? xt(e2, tr.Stringify, false, {}).then(a) : a(e2);
    });
    b(this, "redirect", (e2, t2) => {
      const r = String(e2);
      return this.header("Location", /[^\x00-\xFF]/.test(r) ? encodeURI(r) : r), this.newResponse(null, t2 ?? 302);
    });
    b(this, "notFound", () => (u(this, Ee) ?? g(this, Ee, () => new Response()), u(this, Ee).call(this, this)));
    g(this, je, e), t && (g(this, $, t.executionCtx), this.env = t.env, g(this, Ee, t.notFoundHandler), g(this, Ae, t.path), g(this, Ie, t.matchResult));
  }
  get req() {
    return u(this, Ne) ?? g(this, Ne, new Et(u(this, je), u(this, Ae), u(this, Ie))), u(this, Ne);
  }
  get event() {
    if (u(this, $) && "respondWith" in u(this, $)) return u(this, $);
    throw Error("This context has no FetchEvent");
  }
  get executionCtx() {
    if (u(this, $)) return u(this, $);
    throw Error("This context has no ExecutionContext");
  }
  get res() {
    return u(this, j) || g(this, j, new Response(null, { headers: u(this, ie) ?? g(this, ie, new Headers()) }));
  }
  set res(e) {
    if (u(this, j) && e) {
      e = new Response(e.body, e);
      for (const [t, r] of u(this, j).headers.entries()) if (t !== "content-type") if (t === "set-cookie") {
        const a = u(this, j).headers.getSetCookie();
        e.headers.delete("set-cookie");
        for (const s of a) e.headers.append("set-cookie", s);
      } else e.headers.set(t, r);
    }
    g(this, j, e), this.finalized = true;
  }
  get var() {
    return u(this, U) ? Object.fromEntries(u(this, U)) : {};
  }
}, je = /* @__PURE__ */ new WeakMap(), Ne = /* @__PURE__ */ new WeakMap(), U = /* @__PURE__ */ new WeakMap(), ve = /* @__PURE__ */ new WeakMap(), $ = /* @__PURE__ */ new WeakMap(), j = /* @__PURE__ */ new WeakMap(), Ce = /* @__PURE__ */ new WeakMap(), ye = /* @__PURE__ */ new WeakMap(), Ee = /* @__PURE__ */ new WeakMap(), ie = /* @__PURE__ */ new WeakMap(), Ie = /* @__PURE__ */ new WeakMap(), Ae = /* @__PURE__ */ new WeakMap(), Q = /* @__PURE__ */ new WeakSet(), he = /* @__PURE__ */ __name(function(e, t, r) {
  const a = u(this, j) ? new Headers(u(this, j).headers) : u(this, ie) ?? new Headers();
  if (typeof t == "object" && "headers" in t) {
    const i = t.headers instanceof Headers ? t.headers : new Headers(t.headers);
    for (const [n, o] of i) n.toLowerCase() === "set-cookie" ? a.append(n, o) : a.set(n, o);
  }
  if (r) for (const [i, n] of Object.entries(r)) if (typeof n == "string") a.set(i, n);
  else {
    a.delete(i);
    for (const o of n) a.append(i, o);
  }
  const s = typeof t == "number" ? t : (t == null ? void 0 : t.status) ?? u(this, ve);
  return new Response(e, { status: s, headers: a });
}, "he"), ot);
var O = "ALL";
var sr = "all";
var ir = ["get", "post", "put", "delete", "options", "patch"];
var Rt = "Can not add a route since the matcher is already built.";
var Ot = class extends Error {
  static {
    __name(this, "Ot");
  }
};
var nr = "__COMPOSED_HANDLER";
var or = /* @__PURE__ */ __name((e) => e.text("404 Not Found", 404), "or");
var at = /* @__PURE__ */ __name((e, t) => {
  if ("getResponse" in e) {
    const r = e.getResponse();
    return t.newResponse(r.body, r);
  }
  return console.error(e), t.text("Internal Server Error", 500);
}, "at");
var F;
var T;
var St;
var H;
var ae;
var He;
var ke;
var dt;
var Tt = (dt = class {
  static {
    __name(this, "dt");
  }
  constructor(t = {}) {
    y(this, T);
    b(this, "get");
    b(this, "post");
    b(this, "put");
    b(this, "delete");
    b(this, "options");
    b(this, "patch");
    b(this, "all");
    b(this, "on");
    b(this, "use");
    b(this, "router");
    b(this, "getPath");
    b(this, "_basePath", "/");
    y(this, F, "/");
    b(this, "routes", []);
    y(this, H, or);
    b(this, "errorHandler", at);
    b(this, "onError", (t2) => (this.errorHandler = t2, this));
    b(this, "notFound", (t2) => (g(this, H, t2), this));
    b(this, "fetch", (t2, ...r) => w(this, T, ke).call(this, t2, r[1], r[0], t2.method));
    b(this, "request", (t2, r, a2, s2) => t2 instanceof Request ? this.fetch(r ? new Request(t2, r) : t2, a2, s2) : (t2 = t2.toString(), this.fetch(new Request(/^https?:\/\//.test(t2) ? t2 : `http://localhost${fe("/", t2)}`, r), a2, s2)));
    b(this, "fire", () => {
      addEventListener("fetch", (t2) => {
        t2.respondWith(w(this, T, ke).call(this, t2.request, t2, void 0, t2.request.method));
      });
    });
    [...ir, sr].forEach((i) => {
      this[i] = (n, ...o) => (typeof n == "string" ? g(this, F, n) : w(this, T, ae).call(this, i, u(this, F), n), o.forEach((d) => {
        w(this, T, ae).call(this, i, u(this, F), d);
      }), this);
    }), this.on = (i, n, ...o) => {
      for (const d of [n].flat()) {
        g(this, F, d);
        for (const l of [i].flat()) o.map((c) => {
          w(this, T, ae).call(this, l.toUpperCase(), u(this, F), c);
        });
      }
      return this;
    }, this.use = (i, ...n) => (typeof i == "string" ? g(this, F, i) : (g(this, F, "*"), n.unshift(i)), n.forEach((o) => {
      w(this, T, ae).call(this, O, u(this, F), o);
    }), this);
    const { strict: a, ...s } = t;
    Object.assign(this, s), this.getPath = a ?? true ? t.getPath ?? gt : Qt;
  }
  route(t, r) {
    const a = this.basePath(t);
    return r.routes.map((s) => {
      var n;
      let i;
      r.errorHandler === at ? i = s.handler : (i = /* @__PURE__ */ __name(async (o, d) => (await tt([], r.errorHandler)(o, () => s.handler(o, d))).res, "i"), i[nr] = s.handler), w(n = a, T, ae).call(n, s.method, s.path, i);
    }), this;
  }
  basePath(t) {
    const r = w(this, T, St).call(this);
    return r._basePath = fe(this._basePath, t), r;
  }
  mount(t, r, a) {
    let s, i;
    a && (typeof a == "function" ? i = a : (i = a.optionHandler, a.replaceRequest === false ? s = /* @__PURE__ */ __name((d) => d, "s") : s = a.replaceRequest));
    const n = i ? (d) => {
      const l = i(d);
      return Array.isArray(l) ? l : [l];
    } : (d) => {
      let l;
      try {
        l = d.executionCtx;
      } catch {
      }
      return [d.env, l];
    };
    s || (s = (() => {
      const d = fe(this._basePath, t), l = d === "/" ? 0 : d.length;
      return (c) => {
        const p = new URL(c.url);
        return p.pathname = p.pathname.slice(l) || "/", new Request(p, c);
      };
    })());
    const o = /* @__PURE__ */ __name(async (d, l) => {
      const c = await r(s(d.req.raw), ...n(d));
      if (c) return c;
      await l();
    }, "o");
    return w(this, T, ae).call(this, O, fe(t, "*"), o), this;
  }
}, F = /* @__PURE__ */ new WeakMap(), T = /* @__PURE__ */ new WeakSet(), St = /* @__PURE__ */ __name(function() {
  const t = new Tt({ router: this.router, getPath: this.getPath });
  return t.errorHandler = this.errorHandler, g(t, H, u(this, H)), t.routes = this.routes, t;
}, "St"), H = /* @__PURE__ */ new WeakMap(), ae = /* @__PURE__ */ __name(function(t, r, a) {
  t = t.toUpperCase(), r = fe(this._basePath, r);
  const s = { basePath: this._basePath, path: r, method: t, handler: a };
  this.router.add(t, r, [a, s]), this.routes.push(s);
}, "ae"), He = /* @__PURE__ */ __name(function(t, r) {
  if (t instanceof Error) return this.errorHandler(t, r);
  throw t;
}, "He"), ke = /* @__PURE__ */ __name(function(t, r, a, s) {
  if (s === "HEAD") return (async () => new Response(null, await w(this, T, ke).call(this, t, r, a, "GET")))();
  const i = this.getPath(t, { env: a }), n = this.router.match(s, i), o = new ar(t, { path: i, matchResult: n, env: a, executionCtx: r, notFoundHandler: u(this, H) });
  if (n[0].length === 1) {
    let l;
    try {
      l = n[0][0][0][0](o, async () => {
        o.res = await u(this, H).call(this, o);
      });
    } catch (c) {
      return w(this, T, He).call(this, c, o);
    }
    return l instanceof Promise ? l.then((c) => c || (o.finalized ? o.res : u(this, H).call(this, o))).catch((c) => w(this, T, He).call(this, c, o)) : l ?? u(this, H).call(this, o);
  }
  const d = tt(n[0], this.errorHandler, u(this, H));
  return (async () => {
    try {
      const l = await d(o);
      if (!l.finalized) throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");
      return l.res;
    } catch (l) {
      return w(this, T, He).call(this, l, o);
    }
  })();
}, "ke"), dt);
var Dt = [];
function dr(e, t) {
  const r = this.buildAllMatchers(), a = /* @__PURE__ */ __name((s, i) => {
    const n = r[s] || r[O], o = n[2][i];
    if (o) return o;
    const d = i.match(n[0]);
    if (!d) return [[], Dt];
    const l = d.indexOf("", 1);
    return [n[1][l], d];
  }, "a");
  return this.match = a, a(e, t);
}
__name(dr, "dr");
var Pe = "[^/]+";
var Se = ".*";
var De = "(?:|/.*)";
var ge = Symbol();
var lr = new Set(".\\+*[^]$()");
function cr(e, t) {
  return e.length === 1 ? t.length === 1 ? e < t ? -1 : 1 : -1 : t.length === 1 || e === Se || e === De ? 1 : t === Se || t === De ? -1 : e === Pe ? 1 : t === Pe ? -1 : e.length === t.length ? e < t ? -1 : 1 : t.length - e.length;
}
__name(cr, "cr");
var ne;
var oe;
var k;
var lt;
var Xe = (lt = class {
  static {
    __name(this, "lt");
  }
  constructor() {
    y(this, ne);
    y(this, oe);
    y(this, k, /* @__PURE__ */ Object.create(null));
  }
  insert(t, r, a, s, i) {
    if (t.length === 0) {
      if (u(this, ne) !== void 0) throw ge;
      if (i) return;
      g(this, ne, r);
      return;
    }
    const [n, ...o] = t, d = n === "*" ? o.length === 0 ? ["", "", Se] : ["", "", Pe] : n === "/*" ? ["", "", De] : n.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let l;
    if (d) {
      const c = d[1];
      let p = d[2] || Pe;
      if (c && d[2] && (p === ".*" || (p = p.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:"), /\((?!\?:)/.test(p)))) throw ge;
      if (l = u(this, k)[p], !l) {
        if (Object.keys(u(this, k)).some((m) => m !== Se && m !== De)) throw ge;
        if (i) return;
        l = u(this, k)[p] = new Xe(), c !== "" && g(l, oe, s.varIndex++);
      }
      !i && c !== "" && a.push([c, u(l, oe)]);
    } else if (l = u(this, k)[n], !l) {
      if (Object.keys(u(this, k)).some((c) => c.length > 1 && c !== Se && c !== De)) throw ge;
      if (i) return;
      l = u(this, k)[n] = new Xe();
    }
    l.insert(o, r, a, s, i);
  }
  buildRegExpStr() {
    const r = Object.keys(u(this, k)).sort(cr).map((a) => {
      const s = u(this, k)[a];
      return (typeof u(s, oe) == "number" ? `(${a})@${u(s, oe)}` : lr.has(a) ? `\\${a}` : a) + s.buildRegExpStr();
    });
    return typeof u(this, ne) == "number" && r.unshift(`#${u(this, ne)}`), r.length === 0 ? "" : r.length === 1 ? r[0] : "(?:" + r.join("|") + ")";
  }
}, ne = /* @__PURE__ */ new WeakMap(), oe = /* @__PURE__ */ new WeakMap(), k = /* @__PURE__ */ new WeakMap(), lt);
var Ue;
var Le;
var ct;
var ur = (ct = class {
  static {
    __name(this, "ct");
  }
  constructor() {
    y(this, Ue, { varIndex: 0 });
    y(this, Le, new Xe());
  }
  insert(e, t, r) {
    const a = [], s = [];
    for (let n = 0; ; ) {
      let o = false;
      if (e = e.replace(/\{[^}]+\}/g, (d) => {
        const l = `@\\${n}`;
        return s[n] = [l, d], n++, o = true, l;
      }), !o) break;
    }
    const i = e.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let n = s.length - 1; n >= 0; n--) {
      const [o] = s[n];
      for (let d = i.length - 1; d >= 0; d--) if (i[d].indexOf(o) !== -1) {
        i[d] = i[d].replace(o, s[n][1]);
        break;
      }
    }
    return u(this, Le).insert(i, t, a, u(this, Ue), r), a;
  }
  buildRegExp() {
    let e = u(this, Le).buildRegExpStr();
    if (e === "") return [/^$/, [], []];
    let t = 0;
    const r = [], a = [];
    return e = e.replace(/#(\d+)|@(\d+)|\.\*\$/g, (s, i, n) => i !== void 0 ? (r[++t] = Number(i), "$()") : (n !== void 0 && (a[Number(n)] = ++t), "")), [new RegExp(`^${e}`), r, a];
  }
}, Ue = /* @__PURE__ */ new WeakMap(), Le = /* @__PURE__ */ new WeakMap(), ct);
var pr = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var qe = /* @__PURE__ */ Object.create(null);
function jt(e) {
  return qe[e] ?? (qe[e] = new RegExp(e === "*" ? "" : `^${e.replace(/\/\*$|([.\\+*[^\]$()])/g, (t, r) => r ? `\\${r}` : "(?:|/.*)")}$`));
}
__name(jt, "jt");
function mr() {
  qe = /* @__PURE__ */ Object.create(null);
}
__name(mr, "mr");
function fr(e) {
  var l;
  const t = new ur(), r = [];
  if (e.length === 0) return pr;
  const a = e.map((c) => [!/\*|\/:/.test(c[0]), ...c]).sort(([c, p], [m, f]) => c ? 1 : m ? -1 : p.length - f.length), s = /* @__PURE__ */ Object.create(null);
  for (let c = 0, p = -1, m = a.length; c < m; c++) {
    const [f, _, v] = a[c];
    f ? s[_] = [v.map(([E]) => [E, /* @__PURE__ */ Object.create(null)]), Dt] : p++;
    let h;
    try {
      h = t.insert(_, p, f);
    } catch (E) {
      throw E === ge ? new Ot(_) : E;
    }
    f || (r[p] = v.map(([E, N]) => {
      const B = /* @__PURE__ */ Object.create(null);
      for (N -= 1; N >= 0; N--) {
        const [A, Be] = h[N];
        B[A] = Be;
      }
      return [E, B];
    }));
  }
  const [i, n, o] = t.buildRegExp();
  for (let c = 0, p = r.length; c < p; c++) for (let m = 0, f = r[c].length; m < f; m++) {
    const _ = (l = r[c][m]) == null ? void 0 : l[1];
    if (!_) continue;
    const v = Object.keys(_);
    for (let h = 0, E = v.length; h < E; h++) _[v[h]] = o[_[v[h]]];
  }
  const d = [];
  for (const c in n) d[c] = r[n[c]];
  return [i, d, s];
}
__name(fr, "fr");
function me(e, t) {
  if (e) {
    for (const r of Object.keys(e).sort((a, s) => s.length - a.length)) if (jt(r).test(t)) return [...e[r]];
  }
}
__name(me, "me");
var Z;
var ee;
var $e;
var Nt;
var ut;
var hr = (ut = class {
  static {
    __name(this, "ut");
  }
  constructor() {
    y(this, $e);
    b(this, "name", "RegExpRouter");
    y(this, Z);
    y(this, ee);
    b(this, "match", dr);
    g(this, Z, { [O]: /* @__PURE__ */ Object.create(null) }), g(this, ee, { [O]: /* @__PURE__ */ Object.create(null) });
  }
  add(e, t, r) {
    var o;
    const a = u(this, Z), s = u(this, ee);
    if (!a || !s) throw new Error(Rt);
    a[e] || [a, s].forEach((d) => {
      d[e] = /* @__PURE__ */ Object.create(null), Object.keys(d[O]).forEach((l) => {
        d[e][l] = [...d[O][l]];
      });
    }), t === "/*" && (t = "*");
    const i = (t.match(/\/:/g) || []).length;
    if (/\*$/.test(t)) {
      const d = jt(t);
      e === O ? Object.keys(a).forEach((l) => {
        var c;
        (c = a[l])[t] || (c[t] = me(a[l], t) || me(a[O], t) || []);
      }) : (o = a[e])[t] || (o[t] = me(a[e], t) || me(a[O], t) || []), Object.keys(a).forEach((l) => {
        (e === O || e === l) && Object.keys(a[l]).forEach((c) => {
          d.test(c) && a[l][c].push([r, i]);
        });
      }), Object.keys(s).forEach((l) => {
        (e === O || e === l) && Object.keys(s[l]).forEach((c) => d.test(c) && s[l][c].push([r, i]));
      });
      return;
    }
    const n = bt(t) || [t];
    for (let d = 0, l = n.length; d < l; d++) {
      const c = n[d];
      Object.keys(s).forEach((p) => {
        var m;
        (e === O || e === p) && ((m = s[p])[c] || (m[c] = [...me(a[p], c) || me(a[O], c) || []]), s[p][c].push([r, i - l + d + 1]));
      });
    }
  }
  buildAllMatchers() {
    const e = /* @__PURE__ */ Object.create(null);
    return Object.keys(u(this, ee)).concat(Object.keys(u(this, Z))).forEach((t) => {
      e[t] || (e[t] = w(this, $e, Nt).call(this, t));
    }), g(this, Z, g(this, ee, void 0)), mr(), e;
  }
}, Z = /* @__PURE__ */ new WeakMap(), ee = /* @__PURE__ */ new WeakMap(), $e = /* @__PURE__ */ new WeakSet(), Nt = /* @__PURE__ */ __name(function(e) {
  const t = [];
  let r = e === O;
  return [u(this, Z), u(this, ee)].forEach((a) => {
    const s = a[e] ? Object.keys(a[e]).map((i) => [i, a[e][i]]) : [];
    s.length !== 0 ? (r || (r = true), t.push(...s)) : e !== O && t.push(...Object.keys(a[O]).map((i) => [i, a[O][i]]));
  }), r ? fr(t) : null;
}, "Nt"), ut);
var te;
var W;
var pt;
var gr = (pt = class {
  static {
    __name(this, "pt");
  }
  constructor(e) {
    b(this, "name", "SmartRouter");
    y(this, te, []);
    y(this, W, []);
    g(this, te, e.routers);
  }
  add(e, t, r) {
    if (!u(this, W)) throw new Error(Rt);
    u(this, W).push([e, t, r]);
  }
  match(e, t) {
    if (!u(this, W)) throw new Error("Fatal error");
    const r = u(this, te), a = u(this, W), s = r.length;
    let i = 0, n;
    for (; i < s; i++) {
      const o = r[i];
      try {
        for (let d = 0, l = a.length; d < l; d++) o.add(...a[d]);
        n = o.match(e, t);
      } catch (d) {
        if (d instanceof Ot) continue;
        throw d;
      }
      this.match = o.match.bind(o), g(this, te, [o]), g(this, W, void 0);
      break;
    }
    if (i === s) throw new Error("Fatal error");
    return this.name = `SmartRouter + ${this.activeRouter.name}`, n;
  }
  get activeRouter() {
    if (u(this, W) || u(this, te).length !== 1) throw new Error("No active router has been determined yet.");
    return u(this, te)[0];
  }
}, te = /* @__PURE__ */ new WeakMap(), W = /* @__PURE__ */ new WeakMap(), pt);
var Te = /* @__PURE__ */ Object.create(null);
var re;
var D;
var de;
var _e;
var S;
var J;
var se;
var mt;
var Ct = (mt = class {
  static {
    __name(this, "mt");
  }
  constructor(e, t, r) {
    y(this, J);
    y(this, re);
    y(this, D);
    y(this, de);
    y(this, _e, 0);
    y(this, S, Te);
    if (g(this, D, r || /* @__PURE__ */ Object.create(null)), g(this, re, []), e && t) {
      const a = /* @__PURE__ */ Object.create(null);
      a[e] = { handler: t, possibleKeys: [], score: 0 }, g(this, re, [a]);
    }
    g(this, de, []);
  }
  insert(e, t, r) {
    g(this, _e, ++et(this, _e)._);
    let a = this;
    const s = zt(t), i = [];
    for (let n = 0, o = s.length; n < o; n++) {
      const d = s[n], l = s[n + 1], c = Kt(d, l), p = Array.isArray(c) ? c[0] : d;
      if (p in u(a, D)) {
        a = u(a, D)[p], c && i.push(c[1]);
        continue;
      }
      u(a, D)[p] = new Ct(), c && (u(a, de).push(c), i.push(c[1])), a = u(a, D)[p];
    }
    return u(a, re).push({ [e]: { handler: r, possibleKeys: i.filter((n, o, d) => d.indexOf(n) === o), score: u(this, _e) } }), a;
  }
  search(e, t) {
    var o;
    const r = [];
    g(this, S, Te);
    let s = [this];
    const i = ht(t), n = [];
    for (let d = 0, l = i.length; d < l; d++) {
      const c = i[d], p = d === l - 1, m = [];
      for (let f = 0, _ = s.length; f < _; f++) {
        const v = s[f], h = u(v, D)[c];
        h && (g(h, S, u(v, S)), p ? (u(h, D)["*"] && r.push(...w(this, J, se).call(this, u(h, D)["*"], e, u(v, S))), r.push(...w(this, J, se).call(this, h, e, u(v, S)))) : m.push(h));
        for (let E = 0, N = u(v, de).length; E < N; E++) {
          const B = u(v, de)[E], A = u(v, S) === Te ? {} : { ...u(v, S) };
          if (B === "*") {
            const K = u(v, D)["*"];
            K && (r.push(...w(this, J, se).call(this, K, e, u(v, S))), g(K, S, A), m.push(K));
            continue;
          }
          const [Be, Re, Oe] = B;
          if (!c && !(Oe instanceof RegExp)) continue;
          const P = u(v, D)[Be], Ht = i.slice(d).join("/");
          if (Oe instanceof RegExp) {
            const K = Oe.exec(Ht);
            if (K) {
              if (A[Re] = K[0], r.push(...w(this, J, se).call(this, P, e, u(v, S), A)), Object.keys(u(P, D)).length) {
                g(P, S, A);
                const Ve = ((o = K[0].match(/\//)) == null ? void 0 : o.length) ?? 0;
                (n[Ve] || (n[Ve] = [])).push(P);
              }
              continue;
            }
          }
          (Oe === true || Oe.test(c)) && (A[Re] = c, p ? (r.push(...w(this, J, se).call(this, P, e, A, u(v, S))), u(P, D)["*"] && r.push(...w(this, J, se).call(this, u(P, D)["*"], e, A, u(v, S)))) : (g(P, S, A), m.push(P)));
        }
      }
      s = m.concat(n.shift() ?? []);
    }
    return r.length > 1 && r.sort((d, l) => d.score - l.score), [r.map(({ handler: d, params: l }) => [d, l])];
  }
}, re = /* @__PURE__ */ new WeakMap(), D = /* @__PURE__ */ new WeakMap(), de = /* @__PURE__ */ new WeakMap(), _e = /* @__PURE__ */ new WeakMap(), S = /* @__PURE__ */ new WeakMap(), J = /* @__PURE__ */ new WeakSet(), se = /* @__PURE__ */ __name(function(e, t, r, a) {
  const s = [];
  for (let i = 0, n = u(e, re).length; i < n; i++) {
    const o = u(e, re)[i], d = o[t] || o[O], l = {};
    if (d !== void 0 && (d.params = /* @__PURE__ */ Object.create(null), s.push(d), r !== Te || a && a !== Te)) for (let c = 0, p = d.possibleKeys.length; c < p; c++) {
      const m = d.possibleKeys[c], f = l[d.score];
      d.params[m] = a != null && a[m] && !f ? a[m] : r[m] ?? (a == null ? void 0 : a[m]), l[d.score] = true;
    }
  }
  return s;
}, "se"), mt);
var le;
var ft;
var br = (ft = class {
  static {
    __name(this, "ft");
  }
  constructor() {
    b(this, "name", "TrieRouter");
    y(this, le);
    g(this, le, new Ct());
  }
  add(e, t, r) {
    const a = bt(t);
    if (a) {
      for (let s = 0, i = a.length; s < i; s++) u(this, le).insert(e, a[s], r);
      return;
    }
    u(this, le).insert(e, t, r);
  }
  match(e, t) {
    return u(this, le).search(e, t);
  }
}, le = /* @__PURE__ */ new WeakMap(), ft);
var C = class extends Tt {
  static {
    __name(this, "C");
  }
  constructor(e = {}) {
    super(e), this.router = e.router ?? new gr({ routers: [new hr(), new br()] });
  }
};
var vr = /* @__PURE__ */ __name((e) => {
  const r = { ...{ origin: "*", allowMethods: ["GET", "HEAD", "PUT", "POST", "DELETE", "PATCH"], allowHeaders: [], exposeHeaders: [] }, ...e }, a = /* @__PURE__ */ ((i) => typeof i == "string" ? i === "*" ? () => i : (n) => i === n ? n : null : typeof i == "function" ? i : (n) => i.includes(n) ? n : null)(r.origin), s = ((i) => typeof i == "function" ? i : Array.isArray(i) ? () => i : () => [])(r.allowMethods);
  return async function(n, o) {
    var c;
    function d(p, m) {
      n.res.headers.set(p, m);
    }
    __name(d, "d");
    const l = await a(n.req.header("origin") || "", n);
    if (l && d("Access-Control-Allow-Origin", l), r.origin !== "*") {
      const p = n.req.header("Vary");
      p ? d("Vary", p) : d("Vary", "Origin");
    }
    if (r.credentials && d("Access-Control-Allow-Credentials", "true"), (c = r.exposeHeaders) != null && c.length && d("Access-Control-Expose-Headers", r.exposeHeaders.join(",")), n.req.method === "OPTIONS") {
      r.maxAge != null && d("Access-Control-Max-Age", r.maxAge.toString());
      const p = await s(n.req.header("origin") || "", n);
      p.length && d("Access-Control-Allow-Methods", p.join(","));
      let m = r.allowHeaders;
      if (!(m != null && m.length)) {
        const f = n.req.header("Access-Control-Request-Headers");
        f && (m = f.split(/\s*,\s*/));
      }
      return m != null && m.length && (d("Access-Control-Allow-Headers", m.join(",")), n.res.headers.append("Vary", "Access-Control-Request-Headers")), n.res.headers.delete("Content-Length"), n.res.headers.delete("Content-Type"), new Response(null, { headers: n.res.headers, status: 204, statusText: "No Content" });
    }
    await o();
  };
}, "vr");
var yr = /^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i;
var st = /* @__PURE__ */ __name((e, t = _r) => {
  const r = /\.([a-zA-Z0-9]+?)$/, a = e.match(r);
  if (!a) return;
  let s = t[a[1]];
  return s && s.startsWith("text") && (s += "; charset=utf-8"), s;
}, "st");
var Er = { aac: "audio/aac", avi: "video/x-msvideo", avif: "image/avif", av1: "video/av1", bin: "application/octet-stream", bmp: "image/bmp", css: "text/css", csv: "text/csv", eot: "application/vnd.ms-fontobject", epub: "application/epub+zip", gif: "image/gif", gz: "application/gzip", htm: "text/html", html: "text/html", ico: "image/x-icon", ics: "text/calendar", jpeg: "image/jpeg", jpg: "image/jpeg", js: "text/javascript", json: "application/json", jsonld: "application/ld+json", map: "application/json", mid: "audio/x-midi", midi: "audio/x-midi", mjs: "text/javascript", mp3: "audio/mpeg", mp4: "video/mp4", mpeg: "video/mpeg", oga: "audio/ogg", ogv: "video/ogg", ogx: "application/ogg", opus: "audio/opus", otf: "font/otf", pdf: "application/pdf", png: "image/png", rtf: "application/rtf", svg: "image/svg+xml", tif: "image/tiff", tiff: "image/tiff", ts: "video/mp2t", ttf: "font/ttf", txt: "text/plain", wasm: "application/wasm", webm: "video/webm", weba: "audio/webm", webmanifest: "application/manifest+json", webp: "image/webp", woff: "font/woff", woff2: "font/woff2", xhtml: "application/xhtml+xml", xml: "application/xml", zip: "application/zip", "3gp": "video/3gpp", "3g2": "video/3gpp2", gltf: "model/gltf+json", glb: "model/gltf-binary" };
var _r = Er;
var wr = /* @__PURE__ */ __name((...e) => {
  let t = e.filter((s) => s !== "").join("/");
  t = t.replace(new RegExp("(?<=\\/)\\/+", "g"), "");
  const r = t.split("/"), a = [];
  for (const s of r) s === ".." && a.length > 0 && a.at(-1) !== ".." ? a.pop() : s !== "." && a.push(s);
  return a.join("/") || ".";
}, "wr");
var It = { br: ".br", zstd: ".zst", gzip: ".gz" };
var xr = Object.keys(It);
var Rr = "index.html";
var Or = /* @__PURE__ */ __name((e) => {
  const t = e.root ?? "./", r = e.path, a = e.join ?? wr;
  return async (s, i) => {
    var c, p, m, f;
    if (s.finalized) return i();
    let n;
    if (e.path) n = e.path;
    else try {
      if (n = decodeURIComponent(s.req.path), /(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(n)) throw new Error();
    } catch {
      return await ((c = e.onNotFound) == null ? void 0 : c.call(e, s.req.path, s)), i();
    }
    let o = a(t, !r && e.rewriteRequestPath ? e.rewriteRequestPath(n) : n);
    e.isDir && await e.isDir(o) && (o = a(o, Rr));
    const d = e.getContent;
    let l = await d(o, s);
    if (l instanceof Response) return s.newResponse(l.body, l);
    if (l) {
      const _ = e.mimes && st(o, e.mimes) || st(o);
      if (s.header("Content-Type", _ || "application/octet-stream"), e.precompressed && (!_ || yr.test(_))) {
        const v = new Set((p = s.req.header("Accept-Encoding")) == null ? void 0 : p.split(",").map((h) => h.trim()));
        for (const h of xr) {
          if (!v.has(h)) continue;
          const E = await d(o + It[h], s);
          if (E) {
            l = E, s.header("Content-Encoding", h), s.header("Vary", "Accept-Encoding", { append: true });
            break;
          }
        }
      }
      return await ((m = e.onFound) == null ? void 0 : m.call(e, o, s)), s.body(l);
    }
    await ((f = e.onNotFound) == null ? void 0 : f.call(e, o, s)), await i();
  };
}, "Or");
var Tr = /* @__PURE__ */ __name(async (e, t) => {
  let r;
  t && t.manifest ? typeof t.manifest == "string" ? r = JSON.parse(t.manifest) : r = t.manifest : typeof __STATIC_CONTENT_MANIFEST == "string" ? r = JSON.parse(__STATIC_CONTENT_MANIFEST) : r = __STATIC_CONTENT_MANIFEST;
  let a;
  t && t.namespace ? a = t.namespace : a = __STATIC_CONTENT;
  const s = r[e] || e;
  if (!s) return null;
  const i = await a.get(s, { type: "stream" });
  return i || null;
}, "Tr");
var Sr = /* @__PURE__ */ __name((e) => async function(r, a) {
  return Or({ ...e, getContent: /* @__PURE__ */ __name(async (i) => Tr(i, { manifest: e.manifest, namespace: e.namespace ? e.namespace : r.env ? r.env.__STATIC_CONTENT : void 0 }), "getContent") })(r, a);
}, "Sr");
var Dr = /* @__PURE__ */ __name((e) => Sr(e), "Dr");
async function we(e) {
  const r = new TextEncoder().encode(e), a = await crypto.subtle.digest("SHA-256", r);
  return Array.from(new Uint8Array(a)).map((n) => n.toString(16).padStart(2, "0")).join("");
}
__name(we, "we");
async function At(e, t) {
  return await we(e) === t;
}
__name(At, "At");
async function jr(e) {
  return we(e);
}
__name(jr, "jr");
async function Nr(e, t) {
  const r = { alg: "HS256", typ: "JWT" }, a = { userId: e, email: t, iat: Math.floor(Date.now() / 1e3), exp: Math.floor(Date.now() / 1e3) + 1440 * 60 }, s = btoa(JSON.stringify(r)), i = btoa(JSON.stringify(a)), n = `${s}.${i}`, o = "dom-secret-key-change-in-production", d = new TextEncoder(), l = await crypto.subtle.importKey("raw", d.encode(o), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]), c = await crypto.subtle.sign("HMAC", l, d.encode(n)), p = Array.from(new Uint8Array(c)), m = btoa(String.fromCharCode(...p));
  return `${s}.${i}.${m}`;
}
__name(Nr, "Nr");
async function Cr(e) {
  try {
    const [t, r, a] = e.split("."), s = JSON.parse(atob(r));
    return s.exp < Math.floor(Date.now() / 1e3) ? null : { userId: s.userId, email: s.email };
  } catch {
    return null;
  }
}
__name(Cr, "Cr");
async function Ir(e, t, r, a) {
  const s = `${e}|${t}|${r}|${a}`, n = new TextEncoder().encode(s), o = await crypto.subtle.digest("SHA-256", n);
  return Array.from(new Uint8Array(o)).map((c) => c.toString(16).padStart(2, "0")).join("");
}
__name(Ir, "Ir");
async function M(e, t) {
  const r = e.req.header("Authorization");
  if (!r || !r.startsWith("Bearer ")) return e.json({ error: "Token de autentica\xE7\xE3o n\xE3o fornecido" }, 401);
  const a = r.substring(7), s = await Cr(a);
  if (!s) return e.json({ error: "Token inv\xE1lido ou expirado" }, 401);
  const i = await e.env.DB.prepare("SELECT * FROM users WHERE id = ? AND active = 1").bind(s.userId).first();
  if (!i) return e.json({ error: "Usu\xE1rio n\xE3o encontrado ou inativo" }, 401);
  e.set("user", i), await t();
}
__name(M, "M");
function x(...e) {
  return async (t, r) => {
    const a = t.get("user");
    if (!a) return t.json({ error: "Usu\xE1rio n\xE3o autenticado" }, 401);
    if (!e.includes(a.role)) return t.json({ error: "Permiss\xE3o negada" }, 403);
    await r();
  };
}
__name(x, "x");
var ce = new C();
ce.post("/login", async (e) => {
  try {
    const { email: t, password: r } = await e.req.json();
    if (!t || !r) return e.json({ error: "Email e senha s\xE3o obrigat\xF3rios" }, 400);
    const a = await e.env.DB.prepare("SELECT * FROM users WHERE email = ? AND active = 1").bind(t).first();
    if (!a) return e.json({ error: "Credenciais inv\xE1lidas" }, 401);
    if (!await At(r, a.password_hash)) return e.json({ error: "Credenciais inv\xE1lidas" }, 401);
    await e.env.DB.prepare("UPDATE users SET last_login = datetime('now') WHERE id = ?").bind(a.id).run();
    const i = await Nr(a.id, a.email);
    let n = null;
    a.secretaria_id && (n = await e.env.DB.prepare("SELECT id, name, acronym FROM secretarias WHERE id = ?").bind(a.secretaria_id).first());
    const { password_hash: o, ...d } = a;
    return e.json({ token: i, user: { ...d, secretaria: n } });
  } catch (t) {
    return console.error("Login error:", t), e.json({ error: "Erro ao fazer login" }, 500);
  }
});
ce.post("/register", async (e) => {
  try {
    const { name: t, email: r, password: a, cpf: s, role: i, secretaria_id: n } = await e.req.json();
    if (!t || !r || !a || !i) return e.json({ error: "Dados obrigat\xF3rios faltando" }, 400);
    if (!["admin", "semad", "secretaria", "publico"].includes(i)) return e.json({ error: "Role inv\xE1lida" }, 400);
    if (await e.env.DB.prepare("SELECT id FROM users WHERE email = ?").bind(r).first()) return e.json({ error: "Email j\xE1 cadastrado" }, 400);
    const l = await we(a), c = await e.env.DB.prepare(`
        INSERT INTO users (name, email, password_hash, cpf, role, secretaria_id, active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))
      `).bind(t, r, l, s || null, i, n || null).run();
    return e.json({ message: "Usu\xE1rio cadastrado com sucesso", userId: c.meta.last_row_id }, 201);
  } catch (t) {
    return console.error("Register error:", t), e.json({ error: "Erro ao cadastrar usu\xE1rio" }, 500);
  }
});
ce.post("/change-password", async (e) => {
  try {
    const t = e.get("user");
    if (!t) return e.json({ error: "Usu\xE1rio n\xE3o autenticado" }, 401);
    const { currentPassword: r, newPassword: a } = await e.req.json();
    if (!r || !a) return e.json({ error: "Senhas s\xE3o obrigat\xF3rias" }, 400);
    if (a.length < 6) return e.json({ error: "Nova senha deve ter pelo menos 6 caracteres" }, 400);
    if (!await At(r, t.password_hash)) return e.json({ error: "Senha atual incorreta" }, 401);
    const i = await we(a);
    return await e.env.DB.prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?").bind(i, t.id).run(), e.json({ message: "Senha alterada com sucesso" });
  } catch (t) {
    return console.error("Change password error:", t), e.json({ error: "Erro ao alterar senha" }, 500);
  }
});
ce.get("/me", M, async (e) => {
  try {
    const t = e.get("user");
    if (!t) return e.json({ error: "Usu\xE1rio n\xE3o autenticado" }, 401);
    let r = null;
    t.secretaria_id && (r = await e.env.DB.prepare("SELECT id, name, acronym FROM secretarias WHERE id = ?").bind(t.secretaria_id).first());
    const { password_hash: a, ...s } = t;
    return e.json({ ...s, secretaria: r });
  } catch (t) {
    return console.error("Get user error:", t), e.json({ error: "Erro ao buscar dados do usu\xE1rio" }, 500);
  }
});
ce.post("/forgot-password", async (e) => {
  try {
    const { email: t } = await e.req.json();
    if (!t) return e.json({ error: "Email \xE9 obrigat\xF3rio" }, 400);
    const r = await e.env.DB.prepare("SELECT id, email, name FROM users WHERE email = ? AND active = 1").bind(t).first();
    return r && await e.env.DB.prepare(`
          INSERT INTO audit_logs (user_id, action, entity_type, entity_id, new_values, ip_address, user_agent, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `).bind(r.id, "forgot_password_request", "user", r.id, JSON.stringify({ email: r.email }), e.req.header("cf-connecting-ip") || "unknown", e.req.header("user-agent") || "unknown").run(), e.json({ message: "Se o email existir em nossa base, voc\xEA receber\xE1 instru\xE7\xF5es para redefinir sua senha.", info: "Em produ\xE7\xE3o, um email ser\xE1 enviado. Entre em contato com o administrador do sistema." });
  } catch (t) {
    return console.error("Forgot password error:", t), e.json({ error: "Erro ao processar solicita\xE7\xE3o" }, 500);
  }
});
ce.post("/reset-password", async (e) => {
  try {
    const { token: t, newPassword: r } = await e.req.json();
    return !t || !r ? e.json({ error: "Token e nova senha s\xE3o obrigat\xF3rios" }, 400) : r.length < 6 ? e.json({ error: "Nova senha deve ter pelo menos 6 caracteres" }, 400) : e.json({ error: "Funcionalidade em desenvolvimento. Entre em contato com o administrador do sistema." }, 501);
  } catch (t) {
    return console.error("Reset password error:", t), e.json({ error: "Erro ao redefinir senha" }, 500);
  }
});
var q = new C();
q.use("/*", M);
q.get("/", async (e) => {
  try {
    const t = e.get("user"), { status: r, secretaria_id: a, category_id: s, search: i, page: n = "1", limit: o = "20" } = e.req.query();
    let d = `
      SELECT 
        m.*,
        s.name as secretaria_name,
        s.acronym as secretaria_acronym,
        c.name as category_name,
        u.name as author_name
      FROM matters m
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      LEFT JOIN categories c ON m.category_id = c.id
      LEFT JOIN users u ON m.author_id = u.id
      WHERE 1=1
    `;
    const l = [];
    t.role === "secretaria" && (d += " AND m.secretaria_id = ?", l.push(t.secretaria_id)), r && (d += " AND m.status = ?", l.push(r)), a && (d += " AND m.secretaria_id = ?", l.push(a)), s && (d += " AND m.category_id = ?", l.push(s)), i && (d += " AND (m.title LIKE ? OR m.content LIKE ?)", l.push(`%${i}%`, `%${i}%`)), d += " ORDER BY m.created_at DESC";
    const c = (parseInt(n) - 1) * parseInt(o);
    d += " LIMIT ? OFFSET ?", l.push(parseInt(o), c);
    const m = await e.env.DB.prepare(d).bind(...l).all();
    let f = "SELECT COUNT(*) as total FROM matters m WHERE 1=1";
    const _ = [];
    t.role === "secretaria" && (f += " AND m.secretaria_id = ?", _.push(t.secretaria_id)), r && (f += " AND m.status = ?", _.push(r));
    const v = await e.env.DB.prepare(f).bind(..._).first();
    return e.json({ matters: m.results, pagination: { page: parseInt(n), limit: parseInt(o), total: (v == null ? void 0 : v.total) || 0, totalPages: Math.ceil(((v == null ? void 0 : v.total) || 0) / parseInt(o)) } });
  } catch (t) {
    return console.error("List matters error:", t), e.json({ error: "Erro ao listar mat\xE9rias" }, 500);
  }
});
q.get("/:id", async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), a = await e.env.DB.prepare(`
        SELECT 
          m.*,
          s.name as secretaria_name,
          s.acronym as secretaria_acronym,
          c.name as category_name,
          u.name as author_name,
          r.name as reviewer_name
        FROM matters m
        LEFT JOIN secretarias s ON m.secretaria_id = s.id
        LEFT JOIN categories c ON m.category_id = c.id
        LEFT JOIN users u ON m.author_id = u.id
        LEFT JOIN users r ON m.reviewer_id = r.id
        WHERE m.id = ?
      `).bind(r).first();
    if (!a) return e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
    if (t.role === "secretaria" && a.secretaria_id !== t.secretaria_id) return e.json({ error: "Acesso negado" }, 403);
    const s = await e.env.DB.prepare(`
        SELECT 
          v.*,
          u.name as changed_by_name
        FROM matter_versions v
        LEFT JOIN users u ON v.changed_by = u.id
        WHERE v.matter_id = ?
        ORDER BY v.version DESC
      `).bind(r).all(), i = await e.env.DB.prepare(`
        SELECT 
          c.*,
          u.name as user_name,
          u.role as user_role
        FROM comments c
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.matter_id = ?
        ORDER BY c.created_at DESC
      `).bind(r).all();
    return e.json({ matter: a, versions: s.results, comments: i.results });
  } catch (t) {
    return console.error("Get matter error:", t), e.json({ error: "Erro ao buscar mat\xE9ria" }, 500);
  }
});
q.post("/", x("secretaria", "semad", "admin"), async (e) => {
  try {
    const t = e.get("user"), { title: r, content: a, summary: s, matter_type_id: i, category_id: n, layout_columns: o = 1, priority: d = "normal", publication_date: l, observations: c } = await e.req.json();
    if (!r || !a || !i) return e.json({ error: "Dados obrigat\xF3rios faltando" }, 400);
    const p = t.secretaria_id || 1, m = await e.env.DB.prepare(`
        INSERT INTO matters (
          title, content, summary, matter_type_id, category_id, 
          secretaria_id, author_id, status, version, layout_columns,
          priority, publication_date, observations, server_timestamp,
          created_at, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 'draft', 1, ?, ?, ?, ?, datetime('now'), datetime('now'), datetime('now'))
      `).bind(r, a, s || null, i, n || null, p, t.id, o, d, l || null, c || null).run();
    await e.env.DB.prepare(`
        INSERT INTO matter_versions (matter_id, version, title, content, changed_by, change_description, created_at)
        VALUES (?, 1, ?, ?, ?, 'Vers\xE3o inicial', datetime('now'))
      `).bind(m.meta.last_row_id, r, a, t.id).run();
    const f = e.req.header("CF-Connecting-IP") || e.req.header("X-Real-IP") || "unknown", _ = e.req.header("User-Agent") || "unknown";
    return await e.env.DB.prepare(`
        INSERT INTO audit_logs (user_id, entity_type, entity_id, action, ip_address, user_agent, created_at)
        VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
      `).bind(t.id, "matter", m.meta.last_row_id, "create", f, _).run(), e.json({ message: "Mat\xE9ria criada com sucesso", matterId: m.meta.last_row_id }, 201);
  } catch (t) {
    return console.error("Create matter error:", t), e.json({ error: "Erro ao criar mat\xE9ria" }, 500);
  }
});
q.put("/:id", async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), { title: a, content: s, summary: i, matter_type_id: n, category_id: o, layout_columns: d, priority: l, publication_date: c, observations: p } = await e.req.json(), m = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(r).first();
    if (!m) return e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
    if (t.role === "secretaria" && m.secretaria_id !== t.secretaria_id) return e.json({ error: "Acesso negado" }, 403);
    if (m.status === "published" && t.role !== "admin" && t.role !== "semad") return e.json({ error: "Mat\xE9ria j\xE1 publicada n\xE3o pode ser editada" }, 400);
    const f = m.version + 1;
    return await e.env.DB.prepare(`
        UPDATE matters 
        SET title = ?, content = ?, summary = ?, matter_type_id = ?, 
            category_id = ?, layout_columns = ?, priority = ?, 
            publication_date = ?, observations = ?, 
            version = ?, updated_at = datetime('now')
        WHERE id = ?
      `).bind(a, s, i || null, n, o || null, d, l || "normal", c || null, p || null, f, r).run(), await e.env.DB.prepare(`
        INSERT INTO matter_versions (matter_id, version, title, content, changed_by, change_description, created_at)
        VALUES (?, ?, ?, ?, ?, 'Atualiza\xE7\xE3o manual', datetime('now'))
      `).bind(r, f, a, s, t.id).run(), e.json({ message: "Mat\xE9ria atualizada com sucesso" });
  } catch (t) {
    return console.error("Update matter error:", t), e.json({ error: "Erro ao atualizar mat\xE9ria" }, 500);
  }
});
q.post("/:id/submit", x("secretaria", "semad", "admin"), async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), a = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(r).first();
    if (!a) return e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
    if (t.role === "secretaria" && a.secretaria_id !== t.secretaria_id) return e.json({ error: "Acesso negado" }, 403);
    if (a.status !== "draft") return e.json({ error: "Apenas mat\xE9rias em rascunho podem ser enviadas" }, 400);
    const s = /* @__PURE__ */ new Date(), i = s.getHours(), n = s.getMinutes(), o = i * 60 + n, d = 900, l = 1080, c = 1440;
    if (o > d && o < l) return e.json({ error: "Fora do hor\xE1rio de envio. Envios permitidos at\xE9 15h ou ap\xF3s 18h." }, 400);
    const p = s.toISOString().split("T")[0], m = await e.env.DB.prepare("SELECT * FROM holidays WHERE date = ? AND active = 1").bind(p).first();
    if (m) return e.json({ error: `N\xE3o \xE9 poss\xEDvel enviar mat\xE9rias em feriados. Hoje \xE9: ${m.name}` }, 400);
    const f = await e.env.DB.prepare("SELECT value FROM system_settings WHERE key = 'prazos_dias_uteis'").first();
    let _ = [1, 2, 3, 4, 5];
    if (f && f.value) try {
      _ = JSON.parse(f.value);
    } catch (E) {
      console.error("Error parsing dias_uteis config:", E);
    }
    const v = s.getDay();
    if (!_.includes(v)) {
      const E = ["Domingo", "Segunda", "Ter\xE7a", "Quarta", "Quinta", "Sexta", "S\xE1bado"];
      return e.json({ error: `Hoje (${E[v]}) n\xE3o \xE9 um dia \xFAtil configurado para envio de mat\xE9rias.`, dias_uteis_configurados: _.map((N) => E[N]) }, 400);
    }
    await e.env.DB.prepare(`
        UPDATE matters 
        SET status = 'submitted', submitted_at = datetime('now'), submitted_by = ?, 
            server_timestamp = datetime('now'), updated_at = datetime('now')
        WHERE id = ?
      `).bind(t.id, r).run();
    const h = await e.env.DB.prepare("SELECT id FROM users WHERE role = ? AND active = 1").bind("semad").all();
    for (const E of h.results) await e.env.DB.prepare(`
          INSERT INTO notifications (user_id, matter_id, type, title, message, created_at)
          VALUES (?, ?, 'matter_submitted', ?, ?, datetime('now'))
        `).bind(E.id, r, "Nova mat\xE9ria enviada para an\xE1lise", `A mat\xE9ria "${a.title}" foi enviada para an\xE1lise pela ${t.secretaria_id}`).run();
    return e.json({ message: "Mat\xE9ria enviada para an\xE1lise com sucesso" });
  } catch (t) {
    return console.error("Submit matter error:", t), e.json({ error: "Erro ao enviar mat\xE9ria" }, 500);
  }
});
q.post("/:id/cancel", x("secretaria", "semad", "admin"), async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), { cancelation_reason: a } = await e.req.json();
    if (!a) return e.json({ error: "Motivo do cancelamento \xE9 obrigat\xF3rio" }, 400);
    const s = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(r).first();
    if (!s) return e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
    if (t.role === "secretaria" && s.secretaria_id !== t.secretaria_id) return e.json({ error: "Acesso negado" }, 403);
    if (s.status !== "submitted" && s.status !== "under_review") return e.json({ error: "Apenas mat\xE9rias enviadas podem ser canceladas" }, 400);
    await e.env.DB.prepare(`
        UPDATE matters 
        SET status = 'draft', submitted_at = NULL, submitted_by = NULL,
            reviewer_id = NULL, reviewed_at = NULL, 
            canceled_at = datetime('now'), canceled_by = ?, cancelation_reason = ?,
            updated_at = datetime('now')
        WHERE id = ?
      `).bind(t.id, a, r).run();
    const i = e.req.header("CF-Connecting-IP") || e.req.header("X-Real-IP") || "unknown", n = e.req.header("User-Agent") || "unknown";
    return await e.env.DB.prepare(`
        INSERT INTO audit_logs (user_id, entity_type, entity_id, action, ip_address, user_agent, created_at)
        VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
      `).bind(t.id, "matter", r, "cancel_submission", i, n).run(), e.json({ message: "Envio cancelado. Mat\xE9ria voltou para rascunho." });
  } catch (t) {
    return console.error("Cancel submission error:", t), e.json({ error: "Erro ao cancelar envio" }, 500);
  }
});
q.delete("/:id", x("secretaria"), async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), a = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(r).first();
    if (!a) return e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
    if (a.secretaria_id !== t.secretaria_id) return e.json({ error: "Acesso negado" }, 403);
    if (a.status !== "draft") return e.json({ error: "Apenas rascunhos podem ser exclu\xEDdos" }, 400);
    await e.env.DB.prepare("DELETE FROM matter_versions WHERE matter_id = ?").bind(r).run(), await e.env.DB.prepare("DELETE FROM matters WHERE id = ?").bind(r).run();
    const s = e.req.header("CF-Connecting-IP") || e.req.header("X-Real-IP") || "unknown", i = e.req.header("User-Agent") || "unknown";
    return await e.env.DB.prepare(`
        INSERT INTO audit_logs (user_id, entity_type, entity_id, action, ip_address, user_agent, created_at)
        VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
      `).bind(t.id, "matter", r, "delete", s, i).run(), e.json({ message: "Mat\xE9ria exclu\xEDda com sucesso" });
  } catch (t) {
    return console.error("Delete matter error:", t), e.json({ error: "Erro ao excluir mat\xE9ria" }, 500);
  }
});
q.post("/:id/attachments", async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), a = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(r).first();
    if (!a) return e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
    if (t.role === "secretaria" && a.secretaria_id !== t.secretaria_id) return e.json({ error: "Acesso negado" }, 403);
    const i = (await e.req.formData()).getAll("attachments");
    if (i.length === 0) return e.json({ error: "Nenhum anexo fornecido" }, 400);
    const n = [];
    for (const o of i) {
      if (o.size > 10 * 1024 * 1024) return e.json({ error: `Arquivo ${o.name} excede 10MB` }, 400);
      const d = `${Date.now()}-${o.name}`, l = await o.arrayBuffer(), c = `/api/matters/${r}/attachments/${d}`;
      await e.env.DB.prepare(`
        INSERT INTO attachments (
          matter_id, filename, file_url, original_name, file_type, file_size,
          uploaded_by, uploaded_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
      `).bind(r, d, c, o.name, o.type, o.size, t.id).run(), n.push({ filename: d, original_name: o.name, size: o.size });
    }
    return e.json({ message: `${n.length} anexo(s) enviado(s) com sucesso`, files: n });
  } catch (t) {
    return console.error("Upload attachments error:", t), e.json({ error: "Erro ao fazer upload de anexos" }, 500);
  }
});
q.get("/:id/attachments", async (e) => {
  try {
    const t = e.req.param("id"), { results: r } = await e.env.DB.prepare(`
        SELECT 
          a.*,
          u.name as uploaded_by_name
        FROM attachments a
        LEFT JOIN users u ON a.uploaded_by = u.id
        WHERE a.matter_id = ?
        ORDER BY a.uploaded_at DESC
      `).bind(t).all();
    return e.json({ attachments: r });
  } catch (t) {
    return console.error("List attachments error:", t), e.json({ error: "Erro ao listar anexos" }, 500);
  }
});
var z = new C();
z.use("/*", M);
z.use("/*", x("semad", "admin"));
z.get("/pending", async (e) => {
  try {
    const t = await e.env.DB.prepare(`
        SELECT 
          m.*,
          s.name as secretaria_name,
          s.acronym as secretaria_acronym,
          c.name as category_name,
          u.name as author_name
        FROM matters m
        LEFT JOIN secretarias s ON m.secretaria_id = s.id
        LEFT JOIN categories c ON m.category_id = c.id
        LEFT JOIN users u ON m.author_id = u.id
        WHERE m.status IN ('submitted', 'under_review')
        ORDER BY m.submitted_at ASC
      `).all();
    return e.json({ matters: t.results });
  } catch (t) {
    return console.error("List pending matters error:", t), e.json({ error: "Erro ao listar mat\xE9rias pendentes" }, 500);
  }
});
z.post("/:id/review", async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), a = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(r).first();
    return a ? a.status !== "submitted" ? e.json({ error: "Mat\xE9ria n\xE3o est\xE1 aguardando an\xE1lise" }, 400) : (await e.env.DB.prepare(`
        UPDATE matters 
        SET status = 'under_review', reviewer_id = ?, reviewed_at = datetime('now'), updated_at = datetime('now')
        WHERE id = ?
      `).bind(t.id, r).run(), e.json({ message: "An\xE1lise iniciada com sucesso" })) : e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
  } catch (t) {
    return console.error("Start review error:", t), e.json({ error: "Erro ao iniciar an\xE1lise" }, 500);
  }
});
z.post("/:id/approve", async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), { review_notes: a, scheduled_date: s, signature_password: i } = await e.req.json(), n = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(r).first();
    if (!n) return e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
    if (n.status !== "under_review" && n.status !== "submitted") return e.json({ error: "Mat\xE9ria n\xE3o pode ser aprovada neste status" }, 400);
    const o = (/* @__PURE__ */ new Date()).toISOString(), d = await Ir(n.id, t.id, n.content, o), l = s ? "scheduled" : "approved";
    return await e.env.DB.prepare(`
        UPDATE matters 
        SET 
          status = ?,
          reviewer_id = ?,
          review_notes = ?,
          approved_at = datetime('now'),
          scheduled_date = ?,
          signature_hash = ?,
          signature_type = 'eletronica',
          signed_by = ?,
          signed_at = ?,
          updated_at = datetime('now')
        WHERE id = ?
      `).bind(l, t.id, a || null, s || null, d, t.id, o, r).run(), await e.env.DB.prepare(`
        INSERT INTO notifications (user_id, matter_id, type, title, message, created_at)
        VALUES (?, ?, 'matter_approved', ?, ?, datetime('now'))
      `).bind(n.author_id, r, "Mat\xE9ria aprovada", `Sua mat\xE9ria "${n.title}" foi aprovada pela SEMAD`).run(), e.json({ message: "Mat\xE9ria aprovada com sucesso", signature: d, status: l });
  } catch (t) {
    return console.error("Approve matter error:", t), e.json({ error: "Erro ao aprovar mat\xE9ria" }, 500);
  }
});
z.post("/:id/reject", async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), { rejection_reason: a } = await e.req.json();
    if (!a) return e.json({ error: "Motivo da rejei\xE7\xE3o \xE9 obrigat\xF3rio" }, 400);
    const s = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(r).first();
    return s ? s.status !== "under_review" && s.status !== "submitted" ? e.json({ error: "Mat\xE9ria n\xE3o pode ser rejeitada neste status" }, 400) : (await e.env.DB.prepare(`
        UPDATE matters 
        SET 
          status = 'rejected',
          reviewer_id = ?,
          rejection_reason = ?,
          reviewed_at = datetime('now'),
          updated_at = datetime('now')
        WHERE id = ?
      `).bind(t.id, a, r).run(), await e.env.DB.prepare(`
        INSERT INTO notifications (user_id, matter_id, type, title, message, created_at)
        VALUES (?, ?, 'matter_rejected', ?, ?, datetime('now'))
      `).bind(s.author_id, r, "Mat\xE9ria rejeitada", `Sua mat\xE9ria "${s.title}" foi rejeitada pela SEMAD. Motivo: ${a}`).run(), e.json({ message: "Mat\xE9ria rejeitada com sucesso" })) : e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
  } catch (t) {
    return console.error("Reject matter error:", t), e.json({ error: "Erro ao rejeitar mat\xE9ria" }, 500);
  }
});
z.post("/:id/comment", async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("id"), { comment: a, is_internal: s = true } = await e.req.json();
    return a ? (await e.env.DB.prepare(`
        INSERT INTO comments (matter_id, user_id, comment, is_internal, created_at)
        VALUES (?, ?, ?, ?, datetime('now'))
      `).bind(r, t.id, a, s ? 1 : 0).run(), e.json({ message: "Coment\xE1rio adicionado com sucesso" })) : e.json({ error: "Coment\xE1rio \xE9 obrigat\xF3rio" }, 400);
  } catch (t) {
    return console.error("Add comment error:", t), e.json({ error: "Erro ao adicionar coment\xE1rio" }, 500);
  }
});
z.get("/dashboard", async (e) => {
  try {
    const t = await e.env.DB.prepare(`
        SELECT status, COUNT(*) as count
        FROM matters
        GROUP BY status
      `).all(), r = await e.env.DB.prepare(`
        SELECT COUNT(*) as count
        FROM matters
        WHERE status IN ('submitted', 'under_review')
      `).first(), a = await e.env.DB.prepare(`
        SELECT COUNT(*) as count
        FROM matters
        WHERE status = 'approved' AND DATE(approved_at) = DATE('now')
      `).first(), s = await e.env.DB.prepare(`
        SELECT 
          s.name as secretaria_name,
          s.acronym as secretaria_acronym,
          COUNT(m.id) as count
        FROM matters m
        JOIN secretarias s ON m.secretaria_id = s.id
        GROUP BY s.id, s.name, s.acronym
        ORDER BY count DESC
      `).all();
    return e.json({ statusStats: t.results, pendingCount: (r == null ? void 0 : r.count) || 0, approvedToday: (a == null ? void 0 : a.count) || 0, bySecretaria: s.results });
  } catch (t) {
    return console.error("Dashboard error:", t), e.json({ error: "Erro ao buscar estat\xEDsticas" }, 500);
  }
});
var We = new C();
We.get("/", async (e) => {
  try {
    const t = await e.env.DB.prepare("SELECT * FROM matter_types WHERE active = 1 ORDER BY order_position ASC").all();
    return e.json({ matterTypes: t.results });
  } catch (t) {
    return console.error("List matter types error:", t), e.json({ error: "Erro ao listar tipos de mat\xE9ria" }, 500);
  }
});
We.post("/", async (e) => {
  try {
    const { name: t, description: r, icon: a, color: s, order_position: i } = await e.req.json();
    if (!t) return e.json({ error: "Nome \xE9 obrigat\xF3rio" }, 400);
    const n = await e.env.DB.prepare(`
        INSERT INTO matter_types (name, description, icon, color, order_position, created_at)
        VALUES (?, ?, ?, ?, ?, datetime('now'))
      `).bind(t, r || null, a || null, s || null, i || 0).run();
    return e.json({ message: "Tipo de mat\xE9ria criado com sucesso", id: n.meta.last_row_id }, 201);
  } catch (t) {
    return console.error("Create matter type error:", t), e.json({ error: "Erro ao criar tipo de mat\xE9ria" }, 500);
  }
});
We.put("/:id", async (e) => {
  try {
    const t = e.req.param("id"), { name: r, description: a, icon: s, color: i, order_position: n, active: o } = await e.req.json();
    return await e.env.DB.prepare(`
        UPDATE matter_types 
        SET name = ?, description = ?, icon = ?, color = ?, order_position = ?, active = ?
        WHERE id = ?
      `).bind(r, a || null, s || null, i || null, n, o, t).run(), e.json({ message: "Tipo de mat\xE9ria atualizado com sucesso" });
  } catch (t) {
    return console.error("Update matter type error:", t), e.json({ error: "Erro ao atualizar tipo de mat\xE9ria" }, 500);
  }
});
function Ar(e, t, r = "") {
  const { edition: a, matters: s } = e, i = new Date(a.edition_date), n = i.toLocaleDateString("pt-BR", { weekday: "long" }).toUpperCase(), o = i.getDate(), d = i.toLocaleDateString("pt-BR", { month: "long" }).toUpperCase(), l = i.getFullYear(), c = `${n} * ${o} DE ${d} DE ${l}`, p = {};
  let m = 1;
  s.forEach((h) => {
    const E = h.secretaria_acronym ? `${h.secretaria_acronym.toUpperCase()}` : "OUTROS", N = h.secretaria_name || "Outros", B = h.matter_type_name || "Outros";
    p[E] || (p[E] = { fullName: N, types: {} }), p[E].types[B] || (p[E].types[B] = []), p[E].types[B].push({ ...h, page: m }), m++;
  });
  const _ = `
    <div class="index-section">
      <h2 class="index-title">\xCDNDICE - PREFEITURA MUNICIPAL DE S\xC3O LU\xCDS</h2>
      ${Object.keys(p).sort((h, E) => h.includes("PREFEITURA") ? -1 : E.includes("PREFEITURA") ? 1 : h.localeCompare(E)).map((h) => {
    const E = p[h], N = E.types, B = Object.keys(N).sort();
    return `
          <div class="index-secretaria">
            <h3 class="index-secretaria-name">${E.fullName.toUpperCase()}</h3>
            ${B.map((A) => N[A].map((Re) => `
                <div class="index-item">
                  <span class="index-item-title">${Re.title.toUpperCase()}</span>
                  <span class="index-item-dots">.................................................................</span>
                  <span class="index-item-page">${Re.page}</span>
                </div>
              `).join("")).join("")}
          </div>
        `;
  }).join("")}
    </div>
  `, v = s.map((h, E) => `
      <article class="matter-item ${h.layout_columns === 2 ? "columns-2" : "columns-1"}" data-matter-id="${h.id}">
        <div class="matter-header">
          <h2 class="matter-title">${h.title}</h2>
          <div class="matter-meta">
            <span class="secretaria">${h.secretaria_acronym} - ${h.secretaria_name}</span>
            ${h.summary ? `<p class="matter-summary">${h.summary}</p>` : ""}
          </div>
        </div>
        
        <div class="matter-content">
          ${h.content}
        </div>
        
        <div class="matter-footer">
          <div class="signature-info">
            ${h.signed_at ? `
              <p><strong>Assinado digitalmente em:</strong> ${new Date(h.signed_at).toLocaleString("pt-BR")}</p>
              ${h.signature_hash ? `<p class="signature-hash"><strong>Hash:</strong> ${h.signature_hash.substring(0, 16)}...</p>` : ""}
            ` : ""}
          </div>
          <div class="author-info">
            <p><strong>Respons\xE1vel:</strong> ${h.author_name}</p>
          </div>
        </div>
      </article>
      ${E < s.length - 1 ? '<hr class="matter-divider">' : ""}
    `).join(`
`);
  return `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Di\xE1rio Oficial Municipal - Edi\xE7\xE3o ${a.edition_number}</title>
  <style>
    /* Reset e configura\xE7\xF5es base */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    @page {
      size: A4;
      margin: 2cm 1.5cm;
      
      @top-center {
        content: "Di\xE1rio Oficial Municipal";
        font-family: 'Georgia', serif;
        font-size: 10pt;
        color: #666;
      }
      
      @bottom-center {
        content: "P\xE1gina " counter(page) " de " counter(pages);
        font-family: 'Georgia', serif;
        font-size: 9pt;
        color: #666;
      }
    }
    
    body {
      font-family: 'Georgia', 'Times New Roman', serif;
      font-size: 11pt;
      line-height: 1.6;
      color: #333;
      background: white;
    }
    
    /* Cabe\xE7alho da edi\xE7\xE3o - Estilo do PDF real */
    .edition-header {
      border: 3px solid #0066cc;
      border-radius: 8px;
      padding: 1rem;
      margin-bottom: 2rem;
      page-break-after: avoid;
      background: linear-gradient(to bottom, #f0f9ff 0%, white 100%);
    }
    
    .header-top {
      display: grid;
      grid-template-columns: 1fr auto 1fr;
      align-items: center;
      gap: 1rem;
    }
    
    .header-left, .header-right {
      font-size: 9pt;
      font-weight: bold;
      color: #333;
    }
    
    .header-right {
      text-align: right;
    }
    
    .header-center {
      text-align: center;
    }
    
    .edition-header .logo {
      width: 80px;
      height: 80px;
      margin: 0 auto 0.5rem;
      display: block;
    }
    
    .logo-placeholder {
      font-size: 60px;
      margin: 0 auto 0.5rem;
    }
    
    .edition-header h1 {
      font-size: 36pt;
      font-weight: bold;
      color: #1e40af;
      margin: 0;
      letter-spacing: 2px;
    }
    
    .edition-header .highlight {
      color: #0066cc;
    }
    
    .edition-header .subtitle {
      font-size: 11pt;
      color: #666;
      margin-top: 0.3rem;
    }
    
    /* \xCDndice - Estilo do PDF real */
    .index-section {
      margin: 1rem 0;
      padding: 0;
      background-color: #f8fafc;
      page-break-after: always;
    }
    
    .index-title {
      font-size: 14pt;
      font-weight: bold;
      color: #000;
      text-align: center;
      margin-bottom: 1rem;
      text-transform: uppercase;
      background-color: #e0e0e0;
      padding: 0.5rem;
      border-top: 2px solid #000;
      border-bottom: 2px solid #000;
    }
    
    .index-secretaria {
      margin-bottom: 1rem;
      page-break-inside: avoid;
    }
    
    .index-secretaria-name {
      font-size: 11pt;
      font-weight: bold;
      color: #000;
      margin-bottom: 0.3rem;
      text-transform: uppercase;
      padding: 0.2rem 0;
    }
    
    .index-item {
      display: grid;
      grid-template-columns: 1fr auto auto;
      gap: 0.5rem;
      padding: 0.15rem 0;
      font-size: 9pt;
      line-height: 1.3;
      align-items: center;
    }
    
    .index-item-title {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .index-item-dots {
      color: #ccc;
      overflow: hidden;
      white-space: nowrap;
    }
    
    .index-item-page {
      font-weight: bold;
      min-width: 30px;
      text-align: right;
    }
    
    .index-matter-title {
      flex: 1;
      color: #333;
    }
    
    .index-matter-page {
      margin-left: 1rem;
      color: #666;
      font-weight: bold;
      white-space: nowrap;
    }
    
    /* Mat\xE9rias */
    .matter-item {
      margin-bottom: 2rem;
      page-break-inside: avoid;
    }
    
    .matter-header {
      margin-bottom: 1rem;
      page-break-after: avoid;
    }
    
    .matter-title {
      font-size: 14pt;
      font-weight: bold;
      color: #1e40af;
      margin-bottom: 0.5rem;
      text-transform: uppercase;
    }
    
    .matter-meta {
      font-size: 10pt;
      color: #666;
      margin-bottom: 0.5rem;
    }
    
    .secretaria {
      font-weight: bold;
      color: #059669;
    }
    
    .matter-summary {
      font-style: italic;
      margin-top: 0.5rem;
      color: #555;
    }
    
    .matter-content {
      text-align: justify;
      margin-bottom: 1rem;
      hyphens: auto;
    }
    
    .matter-content p {
      margin-bottom: 0.8rem;
    }
    
    .matter-content h1,
    .matter-content h2,
    .matter-content h3 {
      margin-top: 1rem;
      margin-bottom: 0.5rem;
      color: #1e40af;
    }
    
    .matter-content ul,
    .matter-content ol {
      margin-left: 2rem;
      margin-bottom: 0.8rem;
    }
    
    .matter-content table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 1rem;
    }
    
    .matter-content table th,
    .matter-content table td {
      border: 1px solid #ccc;
      padding: 0.5rem;
      text-align: left;
    }
    
    .matter-content table th {
      background-color: #f3f4f6;
      font-weight: bold;
    }
    
    /* Layout de colunas */
    .columns-2 .matter-content {
      column-count: 2;
      column-gap: 1.5rem;
      column-rule: 1px solid #ddd;
    }
    
    .columns-1 .matter-content {
      column-count: 1;
    }
    
    .matter-footer {
      font-size: 9pt;
      color: #666;
      border-top: 1px solid #e5e7eb;
      padding-top: 0.5rem;
      margin-top: 1rem;
      page-break-inside: avoid;
    }
    
    .signature-info {
      margin-bottom: 0.5rem;
    }
    
    .signature-hash {
      font-family: 'Courier New', monospace;
      font-size: 8pt;
      color: #999;
      word-break: break-all;
    }
    
    .author-info {
      font-style: italic;
    }
    
    .matter-divider {
      border: none;
      border-top: 2px dashed #d1d5db;
      margin: 2rem 0;
    }
    
    /* Rodap\xE9 da edi\xE7\xE3o - Estilo do PDF real */
    .edition-footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background: #f8fafc;
      border-top: 2px solid #0066cc;
      padding: 0.5rem 1rem;
      font-size: 7pt;
      color: #333;
      page-break-inside: avoid;
    }
    
    .footer-content {
      display: grid;
      grid-template-columns: 2fr auto 2fr;
      gap: 1rem;
      align-items: center;
      margin-bottom: 0.3rem;
    }
    
    .footer-left {
      text-align: left;
    }
    
    .footer-center {
      text-align: center;
    }
    
    .footer-right {
      text-align: right;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    
    .footer-text {
      margin: 0;
      line-height: 1.3;
    }
    
    .footer-url {
      margin: 0;
      font-weight: bold;
      color: #0066cc;
    }
    
    .footer-page {
      font-weight: bold;
      font-size: 8pt;
      margin: 0;
    }
    
    .qr-code-placeholder {
      margin-top: 0.2rem;
    }
    
    .validation-info {
      text-align: center;
      padding-top: 0.3rem;
      border-top: 1px solid #ddd;
    }
    
    .validation-hash {
      font-family: 'Courier New', monospace;
      font-size: 7pt;
      color: #666;
      margin: 0;
    }
    
    /* Estilos para impress\xE3o */
    @media print {
      body {
        background: white;
      }
      
      .matter-item {
        page-break-inside: avoid;
      }
      
      .matter-header {
        page-break-after: avoid;
      }
      
      .matter-footer {
        page-break-inside: avoid;
      }
      
      a {
        text-decoration: none;
        color: inherit;
      }
      
      /* Evitar quebra de p\xE1gina em elementos importantes */
      h1, h2, h3, h4, h5, h6 {
        page-break-after: avoid;
      }
      
      img {
        max-width: 100%;
        page-break-inside: avoid;
      }
    }
  </style>
</head>
<body>
  <header class="edition-header">
    <div class="header-top">
      <div class="header-left">S\xC3O LU\xCDS/MA * ${c}</div>
      <div class="header-center">
        ${r ? `<img src="${r}" alt="Bras\xE3o" class="logo">` : '<div class="logo-placeholder">\u{1F3DB}\uFE0F</div>'}
        <h1>Di\xE1rio <span class="highlight">\u{1F5C3}\uFE0F</span> Oficial</h1>
        <p class="subtitle">Munic\xEDpio de S\xE3o Lu\xEDs</p>
      </div>
      <div class="header-right">ANO XLV * N.\xBA ${a.edition_number} * ISSN 2764-8958</div>
    </div>
  </header>
  
  ${_}
  
  <main class="edition-content">
    ${v}
  </main>
  
  <footer class="edition-footer">
    <div class="footer-content">
      <div class="footer-left">
        <p class="footer-text">Este documento pode ser verificado no endere\xE7o eletr\xF4nico</p>
        <p class="footer-url">https://diariooficial.saoluis.ma.gov.br</p>
      </div>
      <div class="footer-center">
        <p class="footer-page"><strong>1 / ${s.length + 1}</strong></p>
      </div>
      <div class="footer-right">
        <p class="footer-text">Documento assinado com certificado digital e carimbo de tempo,</p>
        <p class="footer-text">conforme Instru\xE7\xE3o Normativa N.\xBA 70/2021 do TCE/MA.</p>
        <div class="qr-code-placeholder" title="QR Code para verifica\xE7\xE3o">
          <svg viewBox="0 0 100 100" width="60" height="60">
            <rect width="100" height="100" fill="#fff"/>
            <path d="M10,10 h20 v20 h-20 z M70,10 h20 v20 h-20 z M10,70 h20 v20 h-20 z" fill="#000"/>
            <text x="50" y="55" font-size="12" text-anchor="middle">QR</text>
          </svg>
        </div>
      </div>
    </div>
    <div class="validation-info">
      <p class="validation-hash">
        <strong>C\xF3digo Identificador:</strong> ${t.substring(0, 36)}
      </p>
    </div>
  </footer>
</body>
</html>
  `.trim();
}
__name(Ar, "Ar");
async function Lr(e, t) {
  const r = JSON.stringify({ edition_number: e.edition_number, edition_date: e.edition_date, year: e.year, matter_ids: t.map((a) => a.id).sort(), matter_count: t.length });
  return await jr(r);
}
__name(Lr, "Lr");
async function Lt(e, t, r) {
  try {
    let a = "";
    try {
      const l = await r.prepare("SELECT value FROM system_settings WHERE key = 'logo_url'").first();
      l && l.value && (a = JSON.parse(l.value));
    } catch (l) {
      console.warn("Logo n\xE3o encontrado nas configura\xE7\xF5es:", l);
    }
    const s = await Lr(t.edition, t.matters), i = Ar(t, s, a), n = `diario-oficial-${t.edition.edition_number.replace(/\//g, "-")}-${t.edition.year}.html`;
    await e.put(n, i, { httpMetadata: { contentType: "text/html; charset=utf-8" }, customMetadata: { editionNumber: t.edition.edition_number, editionDate: t.edition.edition_date, year: t.edition.year.toString(), matterCount: t.matters.length.toString(), hash: s } });
    const o = `https://dom-pdfs.your-domain.com/${n}`, d = Math.ceil(t.matters.length * 0.8) + 1;
    return { url: o, hash: s, totalPages: d, htmlContent: i };
  } catch (a) {
    throw console.error("Error generating edition PDF:", a), new Error(`Falha ao gerar PDF: ${a instanceof Error ? a.message : "Erro desconhecido"}`);
  }
}
__name(Lt, "Lt");
var Mr = Object.freeze(Object.defineProperty({ __proto__: null, generateEditionPDF: Lt }, Symbol.toStringTag, { value: "Module" }));
var I = new C();
I.get("/:id/pdf", async (e) => {
  try {
    const t = parseInt(e.req.param("id")), r = await e.env.DB.prepare("SELECT * FROM editions WHERE id = ? AND status = ?").bind(t, "published").first();
    if (!r) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada ou n\xE3o publicada" }, 404);
    const { results: a } = await e.env.DB.prepare(`
      SELECT 
        m.*,
        s.name as secretaria_name,
        s.acronym as secretaria_acronym,
        u.name as author_name,
        em.display_order
      FROM edition_matters em
      INNER JOIN matters m ON em.matter_id = m.id
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      LEFT JOIN users u ON m.author_id = u.id
      WHERE em.edition_id = ?
      ORDER BY em.display_order ASC
    `).bind(t).all(), { generateEditionPDF: s } = await Promise.resolve().then(() => Mr), i = await s(e.env.R2, { edition: r, matters: a }, e.env.DB), n = `diario-oficial-${r.edition_number.replace(/\//g, "-")}-${r.year}.html`;
    return new Response(i.htmlContent, { headers: { "Content-Type": "text/html; charset=utf-8", "Content-Disposition": `attachment; filename="${n}"`, "X-Content-Hash": i.hash } });
  } catch (t) {
    return console.error("Error fetching PDF:", t), e.json({ error: "Erro ao buscar PDF", details: t.message }, 500);
  }
});
I.use("/*", M);
I.get("/", async (e) => {
  try {
    const { status: t, year: r, search: a, page: s = "1", limit: i = "20" } = e.req.query();
    let n = `
      SELECT 
        e.*,
        u.name as published_by_name,
        COUNT(DISTINCT em.matter_id) as matter_count
      FROM editions e
      LEFT JOIN users u ON e.published_by = u.id
      LEFT JOIN edition_matters em ON e.id = em.edition_id
      WHERE 1=1
    `;
    const o = [];
    t && (n += " AND e.status = ?", o.push(t)), r && (n += " AND e.year = ?", o.push(parseInt(r))), a && (n += " AND (e.edition_number LIKE ? OR e.year LIKE ?)", o.push(`%${a}%`, `%${a}%`)), n += `
      GROUP BY e.id
      ORDER BY e.edition_date DESC, e.edition_number DESC
      LIMIT ? OFFSET ?
    `;
    const d = (parseInt(s) - 1) * parseInt(i);
    o.push(parseInt(i), d);
    const l = e.env.DB.prepare(n).bind(...o), { results: c } = await l.all();
    let p = "SELECT COUNT(*) as total FROM editions WHERE 1=1";
    const m = [];
    t && (p += " AND status = ?", m.push(t)), r && (p += " AND year = ?", m.push(parseInt(r)));
    const f = await e.env.DB.prepare(p).bind(...m).first(), _ = (f == null ? void 0 : f.total) || 0;
    return e.json({ editions: c, pagination: { page: parseInt(s), limit: parseInt(i), total: _, pages: Math.ceil(_ / parseInt(i)) } });
  } catch (t) {
    return console.error("Error fetching editions:", t), e.json({ error: "Erro ao buscar edi\xE7\xF5es", details: t.message }, 500);
  }
});
I.get("/:id", async (e) => {
  try {
    const t = parseInt(e.req.param("id")), r = await e.env.DB.prepare(`
      SELECT 
        e.*,
        u.name as published_by_name
      FROM editions e
      LEFT JOIN users u ON e.published_by = u.id
      WHERE e.id = ?
    `).bind(t).first();
    if (!r) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada" }, 404);
    const { results: a } = await e.env.DB.prepare(`
      SELECT 
        m.*,
        em.display_order,
        em.page_start,
        em.page_end,
        em.added_at,
        s.name as secretaria_name,
        s.acronym as secretaria_acronym,
        u.name as author_name
      FROM edition_matters em
      INNER JOIN matters m ON em.matter_id = m.id
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      LEFT JOIN users u ON m.author_id = u.id
      WHERE em.edition_id = ?
      ORDER BY em.display_order ASC
    `).bind(t).all();
    return e.json({ ...r, matters: a || [] });
  } catch (t) {
    return console.error("Error fetching edition:", t), e.json({ error: "Erro ao buscar edi\xE7\xE3o", details: t.message }, 500);
  }
});
I.post("/", x("admin", "semad"), async (e) => {
  try {
    const t = e.get("user");
    let { edition_number: r, edition_date: a, year: s, is_supplemental: i = false } = await e.req.json();
    if (a || (a = (/* @__PURE__ */ new Date()).toISOString().split("T")[0]), s || (s = (/* @__PURE__ */ new Date()).getFullYear()), !r) if (i) {
      const m = await e.env.DB.prepare(`
          SELECT edition_number, supplemental_number FROM editions 
          WHERE year = ? AND is_supplemental = 1
          ORDER BY CAST(COALESCE(supplemental_number, '0') AS INTEGER) DESC 
          LIMIT 1
        `).bind(parseInt(s)).first();
      let f = 1;
      m && m.supplemental_number && (f = parseInt(m.supplemental_number) + 1), r = `${f.toString().padStart(3, "0")}-A/${s}`;
    } else {
      const m = await e.env.DB.prepare(`
          SELECT edition_number FROM editions 
          WHERE year = ? AND (is_supplemental = 0 OR is_supplemental IS NULL)
          ORDER BY CAST(substr(edition_number, 1, instr(edition_number, '/') - 1) AS INTEGER) DESC 
          LIMIT 1
        `).bind(parseInt(s)).first();
      let f = 1;
      if (m && m.edition_number) {
        const v = m.edition_number.match(/^(\d+)/);
        v && (f = parseInt(v[1]) + 1);
      }
      r = `${f.toString().padStart(3, "0")}/${s}`;
    }
    let n = null;
    if (i) {
      const m = r.match(/^(\d+)-[A-Z]\//);
      m && (n = m[1]);
    }
    if (await e.env.DB.prepare("SELECT id FROM editions WHERE edition_number = ?").bind(r).first()) return e.json({ error: "J\xE1 existe uma edi\xE7\xE3o com este n\xFAmero" }, 400);
    const l = (await e.env.DB.prepare(`
      INSERT INTO editions (
        edition_number, edition_date, year, status,
        is_supplemental, supplemental_number,
        created_at, updated_at
      ) VALUES (?, ?, ?, 'draft', ?, ?, datetime('now'), datetime('now'))
    `).bind(r, a, parseInt(s), i ? 1 : 0, n).run()).meta.last_row_id, c = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", p = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "edition", l, "create", JSON.stringify({ edition_number: r, edition_date: a, year: s, is_supplemental: i }), c, p).run(), e.json({ message: i ? "Edi\xE7\xE3o suplementar criada com sucesso" : "Edi\xE7\xE3o criada com sucesso", edition: { id: l, edition_number: r, edition_date: a, year: s, is_supplemental: i, status: "draft" } }, 201);
  } catch (t) {
    return console.error("Error creating edition:", t), e.json({ error: "Erro ao criar edi\xE7\xE3o", details: t.message }, 500);
  }
});
I.put("/:id", x("admin", "semad"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), { edition_number: a, edition_date: s, year: i } = await e.req.json(), n = await e.env.DB.prepare("SELECT * FROM editions WHERE id = ?").bind(r).first();
    if (!n) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada" }, 404);
    if (n.status === "published") return e.json({ error: "N\xE3o \xE9 poss\xEDvel editar uma edi\xE7\xE3o j\xE1 publicada" }, 400);
    await e.env.DB.prepare(`
      UPDATE editions 
      SET edition_number = ?, edition_date = ?, year = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(a, s, parseInt(i), r).run();
    const o = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", d = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        old_values, new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "edition", r, "update", JSON.stringify(n), JSON.stringify({ edition_number: a, edition_date: s, year: i }), o, d).run(), e.json({ message: "Edi\xE7\xE3o atualizada com sucesso" });
  } catch (t) {
    return console.error("Error updating edition:", t), e.json({ error: "Erro ao atualizar edi\xE7\xE3o", details: t.message }, 500);
  }
});
I.post("/:id/add-matter", x("admin", "semad"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), { matter_id: a } = await e.req.json(), s = await e.env.DB.prepare("SELECT * FROM editions WHERE id = ?").bind(r).first();
    if (!s) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada" }, 404);
    if (s.status === "published") return e.json({ error: "N\xE3o \xE9 poss\xEDvel adicionar mat\xE9rias a uma edi\xE7\xE3o j\xE1 publicada" }, 400);
    const i = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(a).first();
    if (!i) return e.json({ error: "Mat\xE9ria n\xE3o encontrada" }, 404);
    if (i.status !== "approved") return e.json({ error: "Apenas mat\xE9rias aprovadas podem ser adicionadas \xE0 edi\xE7\xE3o" }, 400);
    if (await e.env.DB.prepare("SELECT id FROM edition_matters WHERE edition_id = ? AND matter_id = ?").bind(r, a).first()) return e.json({ error: "Mat\xE9ria j\xE1 est\xE1 nesta edi\xE7\xE3o" }, 400);
    const o = await e.env.DB.prepare("SELECT MAX(display_order) as max_order FROM edition_matters WHERE edition_id = ?").bind(r).first(), d = ((o == null ? void 0 : o.max_order) || 0) + 1;
    await e.env.DB.prepare(`
      INSERT INTO edition_matters (
        edition_id, matter_id, display_order, added_by, added_at
      ) VALUES (?, ?, ?, ?, datetime('now'))
    `).bind(r, a, d, t.id).run(), await e.env.DB.prepare("UPDATE matters SET edition_id = ?, updated_at = datetime('now') WHERE id = ?").bind(r, a).run();
    const l = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", c = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "edition_matter", r, "add_matter", JSON.stringify({ matter_id: a, display_order: d }), l, c).run(), e.json({ message: "Mat\xE9ria adicionada \xE0 edi\xE7\xE3o com sucesso", display_order: d });
  } catch (t) {
    return console.error("Error adding matter to edition:", t), e.json({ error: "Erro ao adicionar mat\xE9ria", details: t.message }, 500);
  }
});
I.post("/:id/add-matters", x("admin", "semad"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), { matter_ids: a } = await e.req.json();
    if (!Array.isArray(a) || a.length === 0) return e.json({ error: "matter_ids deve ser um array com pelo menos 1 ID" }, 400);
    const s = await e.env.DB.prepare("SELECT * FROM editions WHERE id = ?").bind(r).first();
    if (!s) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada" }, 404);
    if (s.status === "published") return e.json({ error: "N\xE3o \xE9 poss\xEDvel adicionar mat\xE9rias a uma edi\xE7\xE3o j\xE1 publicada" }, 400);
    const i = await e.env.DB.prepare("SELECT MAX(display_order) as max_order FROM edition_matters WHERE edition_id = ?").bind(r).first();
    let n = ((i == null ? void 0 : i.max_order) || 0) + 1;
    const o = { added: [], skipped: [] };
    for (const c of a) try {
      const p = await e.env.DB.prepare("SELECT * FROM matters WHERE id = ?").bind(c).first();
      if (!p) {
        o.skipped.push({ id: c, reason: "Mat\xE9ria n\xE3o encontrada" });
        continue;
      }
      if (p.status !== "approved") {
        o.skipped.push({ id: c, reason: "Mat\xE9ria n\xE3o aprovada" });
        continue;
      }
      if (await e.env.DB.prepare("SELECT id FROM edition_matters WHERE edition_id = ? AND matter_id = ?").bind(r, c).first()) {
        o.skipped.push({ id: c, reason: "Mat\xE9ria j\xE1 est\xE1 nesta edi\xE7\xE3o" });
        continue;
      }
      await e.env.DB.prepare(`
          INSERT INTO edition_matters (
            edition_id, matter_id, display_order, added_by, added_at
          ) VALUES (?, ?, ?, ?, datetime('now'))
        `).bind(r, c, n, t.id).run(), await e.env.DB.prepare("UPDATE matters SET edition_id = ?, updated_at = datetime('now') WHERE id = ?").bind(r, c).run(), o.added.push(c), n++;
    } catch (p) {
      console.error(`Error adding matter ${c}:`, p), o.skipped.push({ id: c, reason: p instanceof Error ? p.message : "Erro desconhecido" });
    }
    const d = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", l = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "edition_matter", r, "add_multiple_matters", JSON.stringify({ matter_ids: a, results: o }), d, l).run(), e.json({ message: `${o.added.length} mat\xE9rias adicionadas com sucesso`, results: o });
  } catch (t) {
    return console.error("Error adding multiple matters to edition:", t), e.json({ error: "Erro ao adicionar mat\xE9rias", details: t.message }, 500);
  }
});
I.delete("/:id/remove-matter/:matterId", x("admin", "semad"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), a = parseInt(e.req.param("matterId")), s = await e.env.DB.prepare("SELECT * FROM editions WHERE id = ?").bind(r).first();
    if (!s) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada" }, 404);
    if (s.status === "published") return e.json({ error: "N\xE3o \xE9 poss\xEDvel remover mat\xE9rias de uma edi\xE7\xE3o j\xE1 publicada" }, 400);
    await e.env.DB.prepare("DELETE FROM edition_matters WHERE edition_id = ? AND matter_id = ?").bind(r, a).run(), await e.env.DB.prepare("UPDATE matters SET edition_id = NULL, updated_at = datetime('now') WHERE id = ?").bind(a).run();
    const i = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", n = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        old_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "edition_matter", r, "remove_matter", JSON.stringify({ matter_id: a }), i, n).run(), e.json({ message: "Mat\xE9ria removida da edi\xE7\xE3o com sucesso" });
  } catch (t) {
    return console.error("Error removing matter from edition:", t), e.json({ error: "Erro ao remover mat\xE9ria", details: t.message }, 500);
  }
});
I.put("/:id/reorder", x("admin", "semad"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), { matter_orders: a } = await e.req.json(), s = await e.env.DB.prepare("SELECT * FROM editions WHERE id = ?").bind(r).first();
    if (!s) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada" }, 404);
    if (s.status === "published") return e.json({ error: "N\xE3o \xE9 poss\xEDvel reordenar mat\xE9rias de uma edi\xE7\xE3o j\xE1 publicada" }, 400);
    for (const o of a) await e.env.DB.prepare(`
        UPDATE edition_matters 
        SET display_order = ?
        WHERE edition_id = ? AND matter_id = ?
      `).bind(o.display_order, r, o.matter_id).run();
    const i = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", n = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "edition", r, "reorder_matters", JSON.stringify({ matter_orders: a }), i, n).run(), e.json({ message: "Mat\xE9rias reordenadas com sucesso" });
  } catch (t) {
    return console.error("Error reordering matters:", t), e.json({ error: "Erro ao reordenar mat\xE9rias", details: t.message }, 500);
  }
});
I.post("/:id/publish", x("admin", "semad"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), a = await e.env.DB.prepare("SELECT * FROM editions WHERE id = ?").bind(r).first();
    if (!a) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada" }, 404);
    if (a.status === "published") return e.json({ error: "Edi\xE7\xE3o j\xE1 foi publicada" }, 400);
    const s = await e.env.DB.prepare("SELECT COUNT(*) as count FROM edition_matters WHERE edition_id = ?").bind(r).first();
    if (!s || s.count === 0) return e.json({ error: "N\xE3o \xE9 poss\xEDvel publicar uma edi\xE7\xE3o sem mat\xE9rias" }, 400);
    const { results: i } = await e.env.DB.prepare(`
      SELECT 
        m.*,
        s.name as secretaria_name,
        s.acronym as secretaria_acronym,
        u.name as author_name,
        em.display_order
      FROM edition_matters em
      INNER JOIN matters m ON em.matter_id = m.id
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      LEFT JOIN users u ON m.author_id = u.id
      WHERE em.edition_id = ?
      ORDER BY em.display_order ASC
    `).bind(r).all(), n = await Lt(e.env.R2, { edition: a, matters: i }, e.env.DB);
    await e.env.DB.prepare(`
      UPDATE editions 
      SET status = 'published',
          pdf_url = ?,
          pdf_hash = ?,
          total_pages = ?,
          published_at = datetime('now'),
          published_by = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(n.url, n.hash, n.totalPages, t.id, r).run();
    for (const l of i) await e.env.DB.prepare(`
        UPDATE matters 
        SET status = 'published',
            published_at = datetime('now'),
            pdf_url = ?,
            updated_at = datetime('now')
        WHERE id = ?
      `).bind(n.url, l.id).run();
    const o = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", d = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "edition", r, "publish", JSON.stringify({ pdf_url: n.url, pdf_hash: n.hash, total_pages: n.totalPages, matter_count: i.length }), o, d).run(), e.json({ message: "Edi\xE7\xE3o publicada com sucesso", pdf_url: n.url, pdf_hash: n.hash, total_pages: n.totalPages });
  } catch (t) {
    return console.error("Error publishing edition:", t), e.json({ error: "Erro ao publicar edi\xE7\xE3o", details: t.message }, 500);
  }
});
I.delete("/:id", x("admin"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), a = await e.env.DB.prepare("SELECT * FROM editions WHERE id = ?").bind(r).first();
    if (!a) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada" }, 404);
    if (a.status === "published") return e.json({ error: "N\xE3o \xE9 poss\xEDvel excluir uma edi\xE7\xE3o j\xE1 publicada" }, 400);
    await e.env.DB.prepare("DELETE FROM edition_matters WHERE edition_id = ?").bind(r).run(), await e.env.DB.prepare("DELETE FROM editions WHERE id = ?").bind(r).run();
    const s = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", i = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        old_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "edition", r, "delete", JSON.stringify(a), s, i).run(), e.json({ message: "Edi\xE7\xE3o exclu\xEDda com sucesso" });
  } catch (t) {
    return console.error("Error deleting edition:", t), e.json({ error: "Erro ao excluir edi\xE7\xE3o", details: t.message }, 500);
  }
});
I.post("/:id/auto-build", x("admin", "semad"), async (e) => {
  try {
    const t = parseInt(e.req.param("id")), r = e.get("user");
    if (!await e.env.DB.prepare("SELECT * FROM editions WHERE id = ? AND status = ?").bind(t, "draft").first()) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada ou j\xE1 publicada" }, 404);
    const { results: s } = await e.env.DB.prepare(`
      SELECT 
        m.*,
        s.name as secretaria_name,
        s.acronym as secretaria_acronym,
        mt.name as matter_type_name
      FROM matters m
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      LEFT JOIN matter_types mt ON m.matter_type_id = mt.id
      WHERE m.status = 'approved'
        AND m.id NOT IN (
          SELECT matter_id FROM edition_matters WHERE edition_id != ?
        )
      ORDER BY s.name ASC, mt.name ASC, m.title ASC
    `).bind(t).all();
    if (!s || s.length === 0) return e.json({ message: "Nenhuma mat\xE9ria aprovada dispon\xEDvel", matters_added: 0 });
    await e.env.DB.prepare("DELETE FROM edition_matters WHERE edition_id = ?").bind(t).run();
    let i = 1;
    for (const d of s) await e.env.DB.prepare(`
        INSERT INTO edition_matters (edition_id, matter_id, display_order, added_at, added_by)
        VALUES (?, ?, ?, datetime('now'), ?)
      `).bind(t, d.id, i, r.id).run(), i++;
    await e.env.DB.prepare("UPDATE editions SET updated_at = datetime('now') WHERE id = ?").bind(t).run();
    const n = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", o = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(r.id, "edition", t, "auto_build", JSON.stringify({ matters_count: s.length }), n, o).run(), e.json({ message: "Di\xE1rio montado automaticamente com sucesso", matters_added: s.length, matters: s.map((d) => ({ id: d.id, title: d.title, secretaria: d.secretaria_acronym, type: d.matter_type_name })) });
  } catch (t) {
    return console.error("Error auto-building edition:", t), e.json({ error: "Erro ao montar di\xE1rio automaticamente", details: t.message }, 500);
  }
});
var Y = new C();
Y.use("/*", M);
Y.use("/*", x("admin"));
Y.get("/", async (e) => {
  try {
    const { results: t } = await e.env.DB.prepare(`
      SELECT 
        u.id, u.name, u.email, u.cpf, u.role, u.secretaria_id,
        u.active, u.created_at, u.last_login,
        s.name as secretaria_name, s.acronym as secretaria_acronym
      FROM users u
      LEFT JOIN secretarias s ON u.secretaria_id = s.id
      ORDER BY u.name ASC
    `).all();
    return e.json({ users: t });
  } catch (t) {
    return console.error("Error fetching users:", t), e.json({ error: "Erro ao buscar usu\xE1rios", details: t.message }, 500);
  }
});
Y.get("/:id", async (e) => {
  try {
    const t = parseInt(e.req.param("id")), r = await e.env.DB.prepare(`
      SELECT 
        u.id, u.name, u.email, u.cpf, u.role, u.secretaria_id,
        u.active, u.created_at, u.last_login,
        s.name as secretaria_name, s.acronym as secretaria_acronym
      FROM users u
      LEFT JOIN secretarias s ON u.secretaria_id = s.id
      WHERE u.id = ?
    `).bind(t).first();
    return r ? e.json({ user: r }) : e.json({ error: "Usu\xE1rio n\xE3o encontrado" }, 404);
  } catch (t) {
    return console.error("Error fetching user:", t), e.json({ error: "Erro ao buscar usu\xE1rio", details: t.message }, 500);
  }
});
Y.post("/", async (e) => {
  try {
    const t = e.get("user"), { name: r, email: a, cpf: s, password: i, role: n, secretaria_id: o } = await e.req.json();
    if (!r || !a || !i || !n) return e.json({ error: "Campos obrigat\xF3rios: name, email, password, role" }, 400);
    if (await e.env.DB.prepare("SELECT id FROM users WHERE email = ?").bind(a).first()) return e.json({ error: "Email j\xE1 cadastrado" }, 400);
    const l = await we(i), p = (await e.env.DB.prepare(`
      INSERT INTO users (
        name, email, cpf, password_hash, role, secretaria_id, 
        active, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))
    `).bind(r, a, s || null, l, n, o || null).run()).meta.last_row_id, m = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", f = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "user", p, "create", JSON.stringify({ name: r, email: a, role: n, secretaria_id: o }), m, f).run(), e.json({ message: "Usu\xE1rio criado com sucesso", user: { id: p, name: r, email: a, role: n } }, 201);
  } catch (t) {
    return console.error("Error creating user:", t), e.json({ error: "Erro ao criar usu\xE1rio", details: t.message }, 500);
  }
});
Y.put("/:id", async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), { name: a, email: s, cpf: i, role: n, secretaria_id: o, active: d } = await e.req.json(), l = await e.env.DB.prepare("SELECT * FROM users WHERE id = ?").bind(r).first();
    if (!l) return e.json({ error: "Usu\xE1rio n\xE3o encontrado" }, 404);
    if (r === t.id && d === 0) return e.json({ error: "N\xE3o \xE9 poss\xEDvel desativar sua pr\xF3pria conta" }, 400);
    await e.env.DB.prepare(`
      UPDATE users 
      SET name = ?, email = ?, cpf = ?, role = ?, 
          secretaria_id = ?, active = ?, updated_at = datetime('now')
      WHERE id = ?
    `).bind(a, s, i || null, n, o || null, d !== void 0 ? d : 1, r).run();
    const c = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", p = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        old_values, new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "user", r, "update", JSON.stringify(l), JSON.stringify({ name: a, email: s, cpf: i, role: n, secretaria_id: o, active: d }), c, p).run(), e.json({ message: "Usu\xE1rio atualizado com sucesso" });
  } catch (t) {
    return console.error("Error updating user:", t), e.json({ error: "Erro ao atualizar usu\xE1rio", details: t.message }, 500);
  }
});
Y.put("/:id/reset-password", async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), { new_password: a } = await e.req.json();
    if (!a || a.length < 6) return e.json({ error: "Senha deve ter pelo menos 6 caracteres" }, 400);
    if (!await e.env.DB.prepare("SELECT id, name, email FROM users WHERE id = ?").bind(r).first()) return e.json({ error: "Usu\xE1rio n\xE3o encontrado" }, 404);
    const i = await we(a);
    await e.env.DB.prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?").bind(i, r).run();
    const n = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", o = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "user", r, "reset_password", JSON.stringify({ reset_by_admin: t.id }), n, o).run(), e.json({ message: "Senha resetada com sucesso" });
  } catch (t) {
    return console.error("Error resetting password:", t), e.json({ error: "Erro ao resetar senha", details: t.message }, 500);
  }
});
Y.delete("/:id", async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id"));
    if (r === t.id) return e.json({ error: "N\xE3o \xE9 poss\xEDvel excluir sua pr\xF3pria conta" }, 400);
    const a = await e.env.DB.prepare("SELECT * FROM users WHERE id = ?").bind(r).first();
    if (!a) return e.json({ error: "Usu\xE1rio n\xE3o encontrado" }, 404);
    await e.env.DB.prepare("UPDATE users SET active = 0, updated_at = datetime('now') WHERE id = ?").bind(r).run();
    const s = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", i = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        old_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "user", r, "delete", JSON.stringify(a), s, i).run(), e.json({ message: "Usu\xE1rio desativado com sucesso" });
  } catch (t) {
    return console.error("Error deleting user:", t), e.json({ error: "Erro ao excluir usu\xE1rio", details: t.message }, 500);
  }
});
var Je = new C();
Je.post("/edition", async (e) => {
  try {
    const { edition_number: t, year: r, hash: a } = await e.req.json();
    if (!t || !r || !a) return e.json({ error: "Par\xE2metros obrigat\xF3rios: edition_number, year, hash" }, 400);
    const s = await e.env.DB.prepare(`
      SELECT * FROM editions 
      WHERE edition_number = ? AND year = ? AND status = 'published'
    `).bind(t, parseInt(r)).first();
    if (!s) return e.json({ valid: false, message: "Edi\xE7\xE3o n\xE3o encontrada ou n\xE3o publicada" });
    const i = s.pdf_hash === a, { results: n } = await e.env.DB.prepare(`
      SELECT 
        m.id, m.title, m.matter_type_id,
        mt.name as matter_type_name,
        s.acronym as secretaria_acronym,
        u.name as author_name,
        m.published_at
      FROM edition_matters em
      INNER JOIN matters m ON em.matter_id = m.id
      LEFT JOIN matter_types mt ON m.matter_type_id = mt.id
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      LEFT JOIN users u ON m.author_id = u.id
      WHERE em.edition_id = ?
      ORDER BY em.display_order ASC
    `).bind(s.id).all();
    return e.json({ valid: i, message: i ? "Documento aut\xEAntico e \xEDntegro" : "Hash n\xE3o corresponde - documento pode ter sido adulterado", edition: { edition_number: s.edition_number, year: s.year, edition_date: s.edition_date, published_at: s.published_at, total_pages: s.total_pages, matter_count: n.length, pdf_url: s.pdf_url }, matters: i ? n : void 0 });
  } catch (t) {
    return console.error("Error verifying edition:", t), e.json({ error: "Erro ao verificar edi\xE7\xE3o", details: t.message }, 500);
  }
});
Je.post("/matter-signature", async (e) => {
  try {
    const { matter_id: t, signature_hash: r } = await e.req.json();
    if (!t || !r) return e.json({ error: "Par\xE2metros obrigat\xF3rios: matter_id, signature_hash" }, 400);
    const a = await e.env.DB.prepare(`
      SELECT 
        m.*,
        mt.name as matter_type_name,
        s.name as secretaria_name,
        s.acronym as secretaria_acronym,
        u.name as author_name,
        signer.name as signer_name
      FROM matters m
      LEFT JOIN matter_types mt ON m.matter_type_id = mt.id
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      LEFT JOIN users u ON m.author_id = u.id
      LEFT JOIN users signer ON m.signed_by = signer.id
      WHERE m.id = ?
    `).bind(parseInt(t)).first();
    if (!a) return e.json({ valid: false, message: "Mat\xE9ria n\xE3o encontrada" });
    if (!a.signed_at || !a.signature_hash) return e.json({ valid: false, message: "Mat\xE9ria n\xE3o possui assinatura eletr\xF4nica" });
    const s = a.signature_hash === r;
    return e.json({ valid: s, message: s ? "Assinatura v\xE1lida e aut\xEAntica" : "Assinatura inv\xE1lida - documento pode ter sido modificado", matter: { id: a.id, title: a.title, matter_type: a.matter_type_name, secretaria: a.secretaria_name, author: a.author_name, signed_by: a.signer_name, signed_at: a.signed_at, status: a.status } });
  } catch (t) {
    return console.error("Error verifying matter signature:", t), e.json({ error: "Erro ao verificar assinatura", details: t.message }, 500);
  }
});
Je.get("/edition/:edition_number/:year", async (e) => {
  try {
    const t = e.req.param("edition_number"), r = parseInt(e.req.param("year")), a = await e.env.DB.prepare(`
      SELECT 
        e.*,
        publisher.name as published_by_name
      FROM editions e
      LEFT JOIN users publisher ON e.published_by = publisher.id
      WHERE e.edition_number = ? AND e.year = ? AND e.status = 'published'
    `).bind(t, r).first();
    if (!a) return e.json({ error: "Edi\xE7\xE3o n\xE3o encontrada" }, 404);
    const { results: s } = await e.env.DB.prepare(`
      SELECT 
        m.id, m.title, m.signature_hash, m.signed_at,
        mt.name as matter_type_name,
        s.acronym as secretaria_acronym
      FROM edition_matters em
      INNER JOIN matters m ON em.matter_id = m.id
      LEFT JOIN matter_types mt ON m.matter_type_id = mt.id
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      WHERE em.edition_id = ?
      ORDER BY em.display_order ASC
    `).bind(a.id).all();
    return e.json({ edition: { edition_number: a.edition_number, year: a.year, edition_date: a.edition_date, published_at: a.published_at, published_by: a.published_by_name, total_pages: a.total_pages, pdf_hash: a.pdf_hash, pdf_url: a.pdf_url }, matters: s });
  } catch (t) {
    return console.error("Error fetching edition for verification:", t), e.json({ error: "Erro ao buscar edi\xE7\xE3o", details: t.message }, 500);
  }
});
var Me = new C();
function Mt(e, t) {
  const r = t.join(","), a = e.map((s) => t.map((i) => {
    const n = s[i];
    if (n == null) return "";
    const o = String(n);
    return o.includes(",") || o.includes(`
`) || o.includes('"') ? `"${o.replace(/"/g, '""')}"` : o;
  }).join(","));
  return [r, ...a].join(`
`);
}
__name(Mt, "Mt");
function Bt(e, t) {
  const r = `<tr>${t.map((s) => `<th>${s}</th>`).join("")}</tr>`, a = e.map((s) => `<tr>${t.map((i) => `<td>${s[i] || ""}</td>`).join("")}</tr>`).join("");
  return `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
    <head>
      <meta charset="utf-8">
      <style>
        table { border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
      </style>
    </head>
    <body>
      <table>
        <thead>${r}</thead>
        <tbody>${a}</tbody>
      </table>
    </body>
    </html>
  `;
}
__name(Bt, "Bt");
Me.get("/matters/csv", M, async (e) => {
  try {
    const t = e.get("user");
    let r = `
      SELECT 
        m.id,
        m.title,
        m.summary,
        mt.name as tipo,
        s.name as secretaria,
        m.status,
        m.priority,
        u.name as autor,
        m.submission_date as data_envio,
        m.scheduled_date as data_publicacao,
        m.created_at as criado_em
      FROM matters m
      LEFT JOIN matter_types mt ON m.matter_type_id = mt.id
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      LEFT JOIN users u ON m.author_id = u.id
    `;
    t.role === "secretaria" && (r += " WHERE m.secretaria_id = ?"), r += " ORDER BY m.created_at DESC";
    const { results: a } = t.role === "secretaria" ? await e.env.DB.prepare(r).bind(t.secretaria_id).all() : await e.env.DB.prepare(r).all(), s = Mt(a, ["id", "title", "summary", "tipo", "secretaria", "status", "priority", "autor", "data_envio", "data_publicacao", "criado_em"]);
    return new Response(s, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="materias_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv"` } });
  } catch (t) {
    return console.error("Error exporting matters to CSV:", t), e.json({ error: "Erro ao exportar CSV", details: t.message }, 500);
  }
});
Me.get("/matters/xls", M, async (e) => {
  try {
    const t = e.get("user");
    let r = `
      SELECT 
        m.id,
        m.title,
        m.summary,
        mt.name as tipo,
        s.name as secretaria,
        m.status,
        m.priority,
        u.name as autor,
        m.submission_date as data_envio,
        m.scheduled_date as data_publicacao,
        m.created_at as criado_em
      FROM matters m
      LEFT JOIN matter_types mt ON m.matter_type_id = mt.id
      LEFT JOIN secretarias s ON m.secretaria_id = s.id
      LEFT JOIN users u ON m.author_id = u.id
    `;
    t.role === "secretaria" && (r += " WHERE m.secretaria_id = ?"), r += " ORDER BY m.created_at DESC";
    const { results: a } = t.role === "secretaria" ? await e.env.DB.prepare(r).bind(t.secretaria_id).all() : await e.env.DB.prepare(r).all(), s = Bt(a, ["id", "title", "summary", "tipo", "secretaria", "status", "priority", "autor", "data_envio", "data_publicacao", "criado_em"]);
    return new Response(s, { headers: { "Content-Type": "application/vnd.ms-excel; charset=utf-8", "Content-Disposition": `attachment; filename="materias_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.xls"` } });
  } catch (t) {
    return console.error("Error exporting matters to XLS:", t), e.json({ error: "Erro ao exportar XLS", details: t.message }, 500);
  }
});
Me.get("/editions/csv", M, async (e) => {
  try {
    const { results: t } = await e.env.DB.prepare(`
      SELECT 
        e.id,
        e.edition_number as numero,
        e.edition_date as data,
        e.year as ano,
        e.status,
        e.total_pages as paginas,
        COUNT(em.id) as total_materias,
        u.name as publicado_por,
        e.published_at as publicado_em,
        e.created_at as criado_em
      FROM editions e
      LEFT JOIN edition_matters em ON e.id = em.edition_id
      LEFT JOIN users u ON e.published_by = u.id
      GROUP BY e.id
      ORDER BY e.year DESC, e.edition_number DESC
    `).all(), r = Mt(t, ["id", "numero", "data", "ano", "status", "paginas", "total_materias", "publicado_por", "publicado_em", "criado_em"]);
    return new Response(r, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="edicoes_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv"` } });
  } catch (t) {
    return console.error("Error exporting editions to CSV:", t), e.json({ error: "Erro ao exportar CSV", details: t.message }, 500);
  }
});
Me.get("/editions/xls", M, async (e) => {
  try {
    const { results: t } = await e.env.DB.prepare(`
      SELECT 
        e.id,
        e.edition_number as numero,
        e.edition_date as data,
        e.year as ano,
        e.status,
        e.total_pages as paginas,
        COUNT(em.id) as total_materias,
        u.name as publicado_por,
        e.published_at as publicado_em,
        e.created_at as criado_em
      FROM editions e
      LEFT JOIN edition_matters em ON e.id = em.edition_id
      LEFT JOIN users u ON e.published_by = u.id
      GROUP BY e.id
      ORDER BY e.year DESC, e.edition_number DESC
    `).all(), r = Bt(t, ["id", "numero", "data", "ano", "status", "paginas", "total_materias", "publicado_por", "publicado_em", "criado_em"]);
    return new Response(r, { headers: { "Content-Type": "application/vnd.ms-excel; charset=utf-8", "Content-Disposition": `attachment; filename="edicoes_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.xls"` } });
  } catch (t) {
    return console.error("Error exporting editions to XLS:", t), e.json({ error: "Erro ao exportar XLS", details: t.message }, 500);
  }
});
var ue = new C();
ue.get("/", async (e) => {
  try {
    const { results: t } = await e.env.DB.prepare(`
      SELECT 
        s.id,
        s.name,
        s.acronym,
        s.active
      FROM secretarias s
      WHERE s.active = 1
      ORDER BY s.name ASC
    `).all();
    return e.json({ secretarias: t });
  } catch (t) {
    return console.error("Error fetching secretarias:", t), e.json({ error: "Erro ao buscar secretarias", details: t.message }, 500);
  }
});
ue.use("/*", M);
ue.get("/:id", x("admin", "semad"), async (e) => {
  try {
    const t = parseInt(e.req.param("id")), r = await e.env.DB.prepare(`
      SELECT s.* FROM secretarias s WHERE s.id = ?
    `).bind(t).first();
    if (!r) return e.json({ error: "Secretaria n\xE3o encontrada" }, 404);
    const { results: a } = await e.env.DB.prepare(`
      SELECT id, name, email, role, active FROM users 
      WHERE secretaria_id = ?
      ORDER BY name ASC
    `).bind(t).all();
    return e.json({ secretaria: r, users: a });
  } catch (t) {
    return console.error("Error fetching secretaria:", t), e.json({ error: "Erro ao buscar secretaria", details: t.message }, 500);
  }
});
ue.post("/", x("admin"), async (e) => {
  try {
    const t = e.get("user"), { name: r, acronym: a, email: s, phone: i, responsible: n } = await e.req.json();
    if (!r || !a) return e.json({ error: "Nome e sigla s\xE3o obrigat\xF3rios" }, 400);
    if (await e.env.DB.prepare("SELECT id FROM secretarias WHERE acronym = ?").bind(a).first()) return e.json({ error: "Sigla j\xE1 est\xE1 em uso" }, 400);
    const d = await e.env.DB.prepare(`
      INSERT INTO secretarias (
        name, acronym, email, phone, responsible,
        active, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))
    `).bind(r, a.toUpperCase(), s || null, i || null, n || null).run(), l = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", c = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "secretaria", d.meta.last_row_id, "create", JSON.stringify({ name: r, acronym: a }), l, c).run(), e.json({ message: "Secretaria criada com sucesso", id: d.meta.last_row_id }, 201);
  } catch (t) {
    return console.error("Error creating secretaria:", t), e.json({ error: "Erro ao criar secretaria", details: t.message }, 500);
  }
});
ue.put("/:id", x("admin"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), { name: a, acronym: s, email: i, phone: n, responsible: o, active: d } = await e.req.json(), l = await e.env.DB.prepare("SELECT * FROM secretarias WHERE id = ?").bind(r).first();
    if (!l) return e.json({ error: "Secretaria n\xE3o encontrada" }, 404);
    if (s && s !== l.acronym && await e.env.DB.prepare("SELECT id FROM secretarias WHERE acronym = ? AND id != ?").bind(s.toUpperCase(), r).first()) return e.json({ error: "Sigla j\xE1 est\xE1 em uso" }, 400);
    await e.env.DB.prepare(`
      UPDATE secretarias 
      SET name = ?,
          acronym = ?,
          email = ?,
          phone = ?,
          responsible = ?,
          active = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(a || l.name, s ? s.toUpperCase() : l.acronym, i !== void 0 ? i : l.email, n !== void 0 ? n : l.phone, o !== void 0 ? o : l.responsible, d !== void 0 ? d ? 1 : 0 : l.active, r).run();
    const c = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", p = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        old_values, new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "secretaria", r, "update", JSON.stringify(l), JSON.stringify({ name: a, acronym: s, email: i, phone: n, responsible: o, active: d }), c, p).run(), e.json({ message: "Secretaria atualizada com sucesso" });
  } catch (t) {
    return console.error("Error updating secretaria:", t), e.json({ error: "Erro ao atualizar secretaria", details: t.message }, 500);
  }
});
ue.delete("/:id", x("admin"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), a = await e.env.DB.prepare("SELECT * FROM secretarias WHERE id = ?").bind(r).first();
    if (!a) return e.json({ error: "Secretaria n\xE3o encontrada" }, 404);
    const { results: s } = await e.env.DB.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM users WHERE secretaria_id = ?) as total_users,
        (SELECT COUNT(*) FROM matters WHERE secretaria_id = ?) as total_matters
    `).bind(r, r).all(), i = s[0] && (s[0].total_users > 0 || s[0].total_matters > 0);
    return i ? (await e.env.DB.prepare("UPDATE secretarias SET active = 0, updated_at = datetime('now') WHERE id = ?").bind(r).run(), e.json({ message: "Secretaria desativada (possui usu\xE1rios ou mat\xE9rias vinculadas)", soft_delete: true })) : (await e.env.DB.prepare("DELETE FROM secretarias WHERE id = ?").bind(r).run(), e.json({ message: "Secretaria removida com sucesso", soft_delete: false }));
  } catch (t) {
    return console.error("Error deleting secretaria:", t), e.json({ error: "Erro ao deletar secretaria", details: t.message }, 500);
  }
});
var G = new C();
G.get("/logo", async (e) => {
  try {
    const t = await e.env.DB.prepare("SELECT value FROM system_settings WHERE key = 'logo_url'").first();
    return !t || !t.value ? e.json({ logo_url: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+PHRleHQ+TE9HTzwvdGV4dD48L3N2Zz4=" }) : e.json({ logo_url: t.value });
  } catch (t) {
    return console.error("Error fetching logo:", t), e.json({ error: "Erro ao buscar logo", details: t.message }, 500);
  }
});
G.use("/*", M);
G.get("/", x("admin"), async (e) => {
  try {
    const { results: t } = await e.env.DB.prepare(`
      SELECT * FROM system_settings ORDER BY key
    `).all();
    return e.json({ settings: t });
  } catch (t) {
    return console.error("Error fetching settings:", t), e.json({ error: "Erro ao buscar configura\xE7\xF5es", details: t.message }, 500);
  }
});
G.get("/:key", x("admin"), async (e) => {
  try {
    const t = e.req.param("key"), r = await e.env.DB.prepare("SELECT * FROM system_settings WHERE key = ?").bind(t).first();
    return r ? e.json({ setting: r }) : e.json({ error: "Configura\xE7\xE3o n\xE3o encontrada" }, 404);
  } catch (t) {
    return console.error("Error fetching setting:", t), e.json({ error: "Erro ao buscar configura\xE7\xE3o", details: t.message }, 500);
  }
});
G.put("/:key", x("admin"), async (e) => {
  try {
    const t = e.get("user"), r = e.req.param("key"), { value: a, description: s } = await e.req.json(), i = await e.env.DB.prepare("SELECT * FROM system_settings WHERE key = ?").bind(r).first();
    if (!i) return e.json({ error: "Configura\xE7\xE3o n\xE3o encontrada" }, 404);
    if (i.value_type === "boolean" && typeof a != "boolean") return e.json({ error: "Valor deve ser booleano (true/false)" }, 400);
    if (i.value_type === "number" && typeof a != "number") return e.json({ error: "Valor deve ser num\xE9rico" }, 400);
    await e.env.DB.prepare(`
      UPDATE system_settings 
      SET value = ?,
          description = ?,
          updated_at = datetime('now'),
          updated_by = ?
      WHERE key = ?
    `).bind(JSON.stringify(a), s || i.description, t.id, r).run();
    const n = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", o = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        old_values, new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "system_setting", r, "update", i.value, JSON.stringify(a), n, o).run(), e.json({ message: "Configura\xE7\xE3o atualizada com sucesso" });
  } catch (t) {
    return console.error("Error updating setting:", t), e.json({ error: "Erro ao atualizar configura\xE7\xE3o", details: t.message }, 500);
  }
});
G.post("/", x("admin"), async (e) => {
  try {
    const t = e.get("user"), { key: r, value: a, description: s } = await e.req.json();
    return !r || a === void 0 ? e.json({ error: "Chave e valor s\xE3o obrigat\xF3rios" }, 400) : await e.env.DB.prepare("SELECT id FROM system_settings WHERE key = ?").bind(r).first() ? e.json({ error: "Configura\xE7\xE3o j\xE1 existe" }, 400) : (await e.env.DB.prepare(`
      INSERT INTO system_settings (
        key, value, description, updated_at, updated_by
      ) VALUES (?, ?, ?, datetime('now'), ?)
    `).bind(r, JSON.stringify(a), s || null, t.id).run(), e.json({ message: "Configura\xE7\xE3o criada com sucesso" }, 201));
  } catch (t) {
    return console.error("Error creating setting:", t), e.json({ error: "Erro ao criar configura\xE7\xE3o", details: t.message }, 500);
  }
});
G.post("/logo/upload", x("admin"), async (e) => {
  try {
    const t = e.get("user"), a = (await e.req.formData()).get("logo");
    if (!a) return e.json({ error: "Arquivo de logo n\xE3o fornecido" }, 400);
    if (!["image/png", "image/jpeg", "image/jpg", "image/svg+xml"].includes(a.type)) return e.json({ error: "Tipo de arquivo inv\xE1lido. Use PNG, JPG ou SVG" }, 400);
    const i = await a.arrayBuffer(), n = btoa(String.fromCharCode(...new Uint8Array(i))), o = `data:${a.type};base64,${n}`;
    return await e.env.DB.prepare(`
      INSERT INTO system_settings (key, value, description, updated_at, updated_by)
      VALUES ('logo_url', ?, 'Logo da Prefeitura (Base64)', datetime('now'), ?)
      ON CONFLICT(key) DO UPDATE SET
        value = excluded.value,
        updated_at = datetime('now'),
        updated_by = excluded.updated_by
    `).bind(o, t.id).run(), e.json({ message: "Logo enviada com sucesso", logo_url: o.substring(0, 100) + "..." });
  } catch (t) {
    return console.error("Error uploading logo:", t), e.json({ error: "Erro ao enviar logo", details: t.message }, 500);
  }
});
G.post("/bulk", x("admin"), async (e) => {
  try {
    const t = e.get("user"), { settings: r } = await e.req.json();
    if (!Array.isArray(r) || r.length === 0) return e.json({ error: "Array de configura\xE7\xF5es \xE9 obrigat\xF3rio" }, 400);
    let a = 0, s = [];
    for (const i of r) {
      const { key: n, value: o } = i;
      if (!n || o === void 0) {
        s.push({ key: n || "unknown", error: "Chave e valor s\xE3o obrigat\xF3rios" });
        continue;
      }
      try {
        await e.env.DB.prepare("SELECT * FROM system_settings WHERE key = ?").bind(n).first() ? (await e.env.DB.prepare(`
            UPDATE system_settings 
            SET value = ?,
                updated_at = datetime('now'),
                updated_by = ?
            WHERE key = ?
          `).bind(JSON.stringify(o), t.id, n).run(), a++) : (await e.env.DB.prepare(`
            INSERT INTO system_settings (key, value, updated_at, updated_by)
            VALUES (?, ?, datetime('now'), ?)
          `).bind(n, JSON.stringify(o), t.id).run(), a++);
      } catch (d) {
        s.push({ key: n, error: d.message });
      }
    }
    return e.json({ message: `${a} configura\xE7\xE3o(\xF5es) atualizada(s) com sucesso`, updated: a, errors: s.length > 0 ? s : void 0 });
  } catch (t) {
    return console.error("Error bulk updating settings:", t), e.json({ error: "Erro ao atualizar configura\xE7\xF5es", details: t.message }, 500);
  }
});
var pe = new C();
pe.use("/*", M);
pe.get("/", async (e) => {
  try {
    const t = e.req.query("year");
    let r = "SELECT * FROM holidays WHERE 1=1";
    const a = [];
    t && (r += " AND strftime('%Y', date) = ?", a.push(t)), r += " ORDER BY date ASC";
    const s = e.env.DB.prepare(r), { results: i } = await (a.length > 0 ? s.bind(...a) : s).all(), n = { nacional: "national", estadual: "state", municipal: "municipal", ponto_facultativo: "optional" }, o = i.map((d) => ({ ...d, type: n[d.type] || d.type, is_recurring: d.recurring }));
    return e.json({ holidays: o });
  } catch (t) {
    return console.error("Error fetching holidays:", t), e.json({ error: "Erro ao buscar feriados", details: t.message }, 500);
  }
});
pe.get("/:id", async (e) => {
  try {
    const t = parseInt(e.req.param("id")), r = await e.env.DB.prepare("SELECT * FROM holidays WHERE id = ?").bind(t).first();
    if (!r) return e.json({ error: "Feriado n\xE3o encontrado" }, 404);
    const s = { ...r, type: { nacional: "national", estadual: "state", municipal: "municipal", ponto_facultativo: "optional" }[r.type] || r.type, is_recurring: r.recurring };
    return e.json({ holiday: s });
  } catch (t) {
    return console.error("Error fetching holiday:", t), e.json({ error: "Erro ao buscar feriado", details: t.message }, 500);
  }
});
pe.post("/", x("admin"), async (e) => {
  try {
    const t = e.get("user"), { date: r, name: a, type: s, is_recurring: i } = await e.req.json();
    if (!r || !a || !s) return e.json({ error: "Data, nome e tipo s\xE3o obrigat\xF3rios" }, 400);
    const n = { national: "nacional", state: "estadual", municipal: "municipal", optional: "ponto_facultativo" };
    if (!["national", "state", "municipal", "optional"].includes(s)) return e.json({ error: "Tipo inv\xE1lido. Use: national, state, municipal ou optional" }, 400);
    const d = n[s] || s;
    if (await e.env.DB.prepare("SELECT id FROM holidays WHERE date = ?").bind(r).first()) return e.json({ error: "J\xE1 existe um feriado cadastrado nesta data" }, 400);
    const c = (/* @__PURE__ */ new Date(r + "T00:00:00")).getFullYear(), p = await e.env.DB.prepare(`
      INSERT INTO holidays (
        date, name, type, recurring, year, active, created_at, created_by
      ) VALUES (?, ?, ?, ?, ?, 1, datetime('now'), ?)
    `).bind(r, a, d, i ? 1 : 0, c, t.id).run(), m = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", f = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "holiday", p.meta.last_row_id, "create", JSON.stringify({ date: r, name: a, type: s, is_recurring: i }), m, f).run(), e.json({ message: "Feriado criado com sucesso", id: p.meta.last_row_id }, 201);
  } catch (t) {
    return console.error("Error creating holiday:", t), e.json({ error: "Erro ao criar feriado", details: t.message }, 500);
  }
});
pe.put("/:id", x("admin"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), { date: a, name: s, type: i, is_recurring: n } = await e.req.json(), o = await e.env.DB.prepare("SELECT * FROM holidays WHERE id = ?").bind(r).first();
    if (!o) return e.json({ error: "Feriado n\xE3o encontrado" }, 404);
    const d = { national: "nacional", state: "estadual", municipal: "municipal", optional: "ponto_facultativo" };
    if (i && !["national", "state", "municipal", "optional"].includes(i)) return e.json({ error: "Tipo inv\xE1lido. Use: national, state, municipal ou optional" }, 400);
    const l = i ? d[i] || i : o.type;
    if (a && a !== o.date && await e.env.DB.prepare("SELECT id FROM holidays WHERE date = ? AND id != ?").bind(a, r).first()) return e.json({ error: "J\xE1 existe um feriado cadastrado nesta data" }, 400);
    const c = a || o.date, p = (/* @__PURE__ */ new Date(c + "T00:00:00")).getFullYear();
    await e.env.DB.prepare(`
      UPDATE holidays 
      SET date = ?,
          name = ?,
          type = ?,
          recurring = ?,
          year = ?
      WHERE id = ?
    `).bind(c, s || o.name, l, n !== void 0 ? n ? 1 : 0 : o.recurring, p, r).run();
    const m = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", f = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        old_values, new_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "holiday", r, "update", JSON.stringify(o), JSON.stringify({ date: a, name: s, type: i, is_recurring: n }), m, f).run(), e.json({ message: "Feriado atualizado com sucesso" });
  } catch (t) {
    return console.error("Error updating holiday:", t), e.json({ error: "Erro ao atualizar feriado", details: t.message }, 500);
  }
});
pe.delete("/:id", x("admin"), async (e) => {
  try {
    const t = e.get("user"), r = parseInt(e.req.param("id")), a = await e.env.DB.prepare("SELECT * FROM holidays WHERE id = ?").bind(r).first();
    if (!a) return e.json({ error: "Feriado n\xE3o encontrado" }, 404);
    await e.env.DB.prepare("DELETE FROM holidays WHERE id = ?").bind(r).run();
    const s = e.req.header("cf-connecting-ip") || e.req.header("x-forwarded-for") || "unknown", i = e.req.header("user-agent") || "unknown";
    return await e.env.DB.prepare(`
      INSERT INTO audit_logs (
        user_id, entity_type, entity_id, action,
        old_values, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).bind(t.id, "holiday", r, "delete", JSON.stringify(a), s, i).run(), e.json({ message: "Feriado removido com sucesso" });
  } catch (t) {
    return console.error("Error deleting holiday:", t), e.json({ error: "Erro ao deletar feriado", details: t.message }, 500);
  }
});
var xe = new C();
xe.get("/stats", async (e) => {
  try {
    const { DB: t } = e.env, r = await t.prepare(`
      SELECT COUNT(*) as count FROM editions 
      WHERE status = 'published'
    `).first(), a = await t.prepare(`
      SELECT COUNT(*) as count FROM matters 
      WHERE status = 'published'
    `).first(), s = await t.prepare(`
      SELECT COUNT(*) as count FROM editions 
      WHERE status = 'published' 
      AND strftime('%Y-%m', edition_date) = strftime('%Y-%m', 'now')
    `).first();
    return e.json({ total_editions: (r == null ? void 0 : r.count) || 0, total_matters: (a == null ? void 0 : a.count) || 0, this_month: (s == null ? void 0 : s.count) || 0 });
  } catch (t) {
    return console.error("Error fetching portal stats:", t), e.json({ error: "Erro ao buscar estat\xEDsticas" }, 500);
  }
});
xe.get("/editions", async (e) => {
  try {
    const { DB: t } = e.env, r = parseInt(e.req.query("limit") || "10"), a = await t.prepare(`
      SELECT 
        e.id,
        e.edition_number,
        e.edition_date,
        e.year,
        e.is_supplemental,
        e.published_at,
        COUNT(em.matter_id) as matter_count
      FROM editions e
      LEFT JOIN edition_matters em ON e.id = em.edition_id
      WHERE e.status = 'published'
      GROUP BY e.id
      ORDER BY e.published_at DESC
      LIMIT ?
    `).bind(r).all();
    return e.json({ editions: a.results || [] });
  } catch (t) {
    return console.error("Error fetching portal editions:", t), e.json({ error: "Erro ao buscar edi\xE7\xF5es" }, 500);
  }
});
xe.get("/search", async (e) => {
  var t;
  try {
    const { DB: r } = e.env, a = e.req.query("q") || "", s = parseInt(e.req.query("limit") || "20");
    if (!a || a.trim().length < 3) return e.json({ results: [], message: "Digite pelo menos 3 caracteres para pesquisar" });
    const i = `%${a.trim()}%`, n = await r.prepare(`
      SELECT 
        m.id,
        m.title,
        m.content,
        m.created_at,
        s.name as secretaria_name,
        mt.name as matter_type_name,
        e.edition_number,
        e.year as edition_year
      FROM matters m
      INNER JOIN secretarias s ON m.secretaria_id = s.id
      INNER JOIN matter_types mt ON m.matter_type_id = mt.id
      LEFT JOIN edition_matters em ON m.id = em.matter_id
      LEFT JOIN editions e ON em.edition_id = e.id
      WHERE m.status = 'published'
      AND (m.title LIKE ? OR m.content LIKE ?)
      ORDER BY m.created_at DESC
      LIMIT ?
    `).bind(i, i, s).all();
    return e.json({ results: n.results || [], count: ((t = n.results) == null ? void 0 : t.length) || 0, query: a });
  } catch (r) {
    return console.error("Error searching portal:", r), e.json({ error: "Erro ao pesquisar publica\xE7\xF5es" }, 500);
  }
});
xe.get("/analytics", async (e) => {
  try {
    const { DB: t } = e.env, r = await t.prepare(`
      SELECT 
        s.acronym,
        s.name,
        COUNT(m.id) as count
      FROM secretarias s
      LEFT JOIN matters m ON s.id = m.secretaria_id AND m.status = 'published'
      GROUP BY s.id
      ORDER BY count DESC
      LIMIT 10
    `).all(), a = await t.prepare(`
      SELECT 
        mt.name,
        COUNT(m.id) as count
      FROM matter_types mt
      LEFT JOIN matters m ON mt.id = m.matter_type_id AND m.status = 'published'
      GROUP BY mt.id
      ORDER BY count DESC
      LIMIT 10
    `).all(), s = await t.prepare(`
      SELECT 
        strftime('%Y-%m', e.edition_date) as month,
        COUNT(DISTINCT e.id) as editions,
        COUNT(m.id) as matters
      FROM editions e
      LEFT JOIN edition_matters em ON e.id = em.edition_id
      LEFT JOIN matters m ON em.matter_id = m.id
      WHERE e.status = 'published'
      AND e.edition_date >= date('now', '-6 months')
      GROUP BY month
      ORDER BY month ASC
    `).all();
    return e.json({ by_secretaria: r.results || [], by_type: a.results || [], trend: s.results || [] });
  } catch (t) {
    return console.error("Error fetching analytics:", t), e.json({ error: "Erro ao buscar an\xE1lises" }, 500);
  }
});
xe.get("/most-searched", async (e) => {
  const t = [{ term: "Decreto", count: 156 }, { term: "Portaria", count: 134 }, { term: "Edital", count: 98 }, { term: "Licita\xE7\xE3o", count: 87 }, { term: "Concurso", count: 76 }, { term: "Contrato", count: 65 }, { term: "Nomea\xE7\xE3o", count: 54 }, { term: "Exonera\xE7\xE3o", count: 43 }];
  return e.json({ terms: t });
});
var R = new C();
R.use("/api/*", vr());
R.use("/static/*", Dr({ root: "./public" }));
R.route("/api/auth", ce);
R.route("/api/matters", q);
R.route("/api/semad", z);
R.route("/api/matter-types", We);
R.route("/api/editions", I);
R.route("/api/users", Y);
R.route("/api/verification", Je);
R.route("/api/export", Me);
R.route("/api/secretarias", ue);
R.route("/api/settings", G);
R.route("/api/holidays", pe);
R.route("/api/portal", xe);
R.get("/api/health", (e) => e.json({ status: "ok", timestamp: (/* @__PURE__ */ new Date()).toISOString(), service: "DOM - Di\xE1rio Oficial Municipal" }));
R.get("/verificar", (e) => e.html(`
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Autenticidade - DOM</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        
        /* WebGL Canvas Background */
        #webgl-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }
        
        .verify-container {
            position: relative;
            z-index: 1;
        }
        
        .verify-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        
        .result-valid {
            animation: slideIn 0.5s ease-out;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 min-h-screen">
    <!-- WebGL Canvas -->
    <canvas id="webgl-background"></canvas>
    
    <!-- Navbar -->
    <nav class="verify-container bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg border-b border-white border-opacity-20 py-4">
        <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <div class="flex items-center space-x-3">
                <i class="fas fa-shield-alt text-white text-3xl"></i>
                <div>
                    <h1 class="text-white text-xl font-bold">Verifica\xE7\xE3o de Autenticidade</h1>
                    <p class="text-blue-200 text-sm">Di\xE1rio Oficial Municipal - S\xE3o Lu\xEDs/MA</p>
                </div>
            </div>
            <div class="flex space-x-4">
                <a href="https://www.saoluis.ma.gov.br" target="_blank" class="text-white hover:text-blue-200 transition">
                    <i class="fas fa-home mr-2"></i>Portal da Prefeitura
                </a>
                <a href="/" class="text-white hover:text-blue-200 transition">
                    <i class="fas fa-sign-in-alt mr-2"></i>\xC1rea Restrita
                </a>
            </div>
        </div>
    </nav>
    
    <!-- Main Content -->
    <div class="verify-container max-w-5xl mx-auto px-4 py-12">
        <!-- Hero Section -->
        <div class="text-center mb-12">
            <div class="inline-block bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg rounded-full p-6 mb-6">
                <i class="fas fa-certificate text-white text-6xl"></i>
            </div>
            <h2 class="text-4xl font-bold text-white mb-4">Verifique a Autenticidade</h2>
            <p class="text-blue-200 text-lg max-w-2xl mx-auto">
                Valide documentos oficiais usando os hashes de seguran\xE7a. 
                Garantimos a integridade e autenticidade de todas as publica\xE7\xF5es.
            </p>
        </div>
        
        <!-- Verification Cards -->
        <div class="grid md:grid-cols-2 gap-8 mb-12">
            <!-- Verificar Edi\xE7\xE3o -->
            <div class="verify-card rounded-2xl p-8">
                <div class="flex items-center mb-6">
                    <div class="bg-gradient-to-br from-blue-500 to-purple-600 rounded-full p-4 mr-4">
                        <i class="fas fa-book text-white text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800">Verificar Edi\xE7\xE3o</h3>
                        <p class="text-gray-600 text-sm">Valide uma edi\xE7\xE3o completa do di\xE1rio</p>
                    </div>
                </div>
                
                <div class="space-y-4">
                    <input 
                        type="text" 
                        id="editionNumber" 
                        placeholder="N\xBA da Edi\xE7\xE3o (ex: 001/2025)" 
                        class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition"
                    >
                    <input 
                        type="number" 
                        id="editionYear" 
                        placeholder="Ano (ex: 2025)" 
                        class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition"
                    >
                    <input 
                        type="text" 
                        id="editionHash" 
                        placeholder="Hash de Valida\xE7\xE3o" 
                        class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition"
                    >
                    <button 
                        onclick="verifyEdition()" 
                        class="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3 rounded-lg transition transform hover:scale-105"
                    >
                        <i class="fas fa-check-circle mr-2"></i>Verificar Edi\xE7\xE3o
                    </button>
                </div>
                
                <div id="editionResult" class="mt-6"></div>
            </div>
            
            <!-- Verificar Assinatura -->
            <div class="verify-card rounded-2xl p-8">
                <div class="flex items-center mb-6">
                    <div class="bg-gradient-to-br from-green-500 to-teal-600 rounded-full p-4 mr-4">
                        <i class="fas fa-signature text-white text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800">Verificar Assinatura</h3>
                        <p class="text-gray-600 text-sm">Valide uma assinatura eletr\xF4nica</p>
                    </div>
                </div>
                
                <div class="space-y-4">
                    <input 
                        type="number" 
                        id="matterId" 
                        placeholder="ID da Mat\xE9ria" 
                        class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none transition"
                    >
                    <input 
                        type="text" 
                        id="signatureHash" 
                        placeholder="Hash da Assinatura" 
                        class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none transition"
                    >
                    <button 
                        onclick="verifySignature()" 
                        class="w-full bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white font-bold py-3 rounded-lg transition transform hover:scale-105"
                    >
                        <i class="fas fa-check-circle mr-2"></i>Verificar Assinatura
                    </button>
                </div>
                
                <div id="signatureResult" class="mt-6"></div>
            </div>
        </div>
        
        <!-- Info Box -->
        <div class="verify-card rounded-2xl p-8">
            <h4 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-info-circle text-blue-600 mr-3"></i>
                Como obter os c\xF3digos de verifica\xE7\xE3o?
            </h4>
            <div class="grid md:grid-cols-2 gap-6">
                <div>
                    <h5 class="font-bold text-gray-700 mb-2">Hash da Edi\xE7\xE3o</h5>
                    <ul class="text-gray-600 text-sm space-y-1">
                        <li><i class="fas fa-arrow-right text-blue-500 mr-2"></i>Encontrado no rodap\xE9 do PDF publicado</li>
                        <li><i class="fas fa-arrow-right text-blue-500 mr-2"></i>C\xF3digo alfanum\xE9rico de 64 caracteres</li>
                        <li><i class="fas fa-arrow-right text-blue-500 mr-2"></i>Valida toda a edi\xE7\xE3o do di\xE1rio</li>
                    </ul>
                </div>
                <div>
                    <h5 class="font-bold text-gray-700 mb-2">Hash da Assinatura</h5>
                    <ul class="text-gray-600 text-sm space-y-1">
                        <li><i class="fas fa-arrow-right text-green-500 mr-2"></i>Presente no cabe\xE7alho de cada mat\xE9ria</li>
                        <li><i class="fas fa-arrow-right text-green-500 mr-2"></i>Valida\xE7\xE3o eletr\xF4nica individual</li>
                        <li><i class="fas fa-arrow-right text-green-500 mr-2"></i>Garante integridade do documento</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="verify-container text-center py-8 text-white text-sm mt-12">
        <p class="mb-2">\xA9 2025 Prefeitura Municipal de S\xE3o Lu\xEDs - MA</p>
        <p class="text-blue-200">Sistema Oficial de Publica\xE7\xF5es | Todos os direitos reservados</p>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"><\/script>
    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"><\/script>
    <script src="/static/webgl-init.js"><\/script>
    <script>
        async function verifyEdition() {
            const editionNumber = document.getElementById('editionNumber').value.trim();
            const year = document.getElementById('editionYear').value;
            const hash = document.getElementById('editionHash').value.trim();
            const resultDiv = document.getElementById('editionResult');
            
            if (!editionNumber || !year || !hash) {
                resultDiv.innerHTML = \`
                    <div class="bg-red-100 border-2 border-red-300 text-red-800 px-4 py-3 rounded-lg">
                        <i class="fas fa-exclamation-triangle mr-2"></i>Preencha todos os campos
                    </div>
                \`;
                return;
            }
            
            resultDiv.innerHTML = \`
                <div class="bg-gray-100 border-2 border-gray-300 text-gray-800 px-4 py-3 rounded-lg">
                    <i class="fas fa-spinner fa-spin mr-2"></i>Verificando...
                </div>
            \`;
            
            try {
                const { data } = await axios.post('/api/verification/edition', {
                    edition_number: editionNumber,
                    year: parseInt(year),
                    hash: hash
                });
                
                if (data.valid) {
                    resultDiv.innerHTML = \`
                        <div class="result-valid bg-green-100 border-2 border-green-300 text-green-800 px-4 py-4 rounded-lg">
                            <div class="flex items-start mb-3">
                                <i class="fas fa-check-circle text-3xl mr-3 mt-1"></i>
                                <div>
                                    <p class="font-bold text-lg">\${data.message}</p>
                                    <p class="text-sm mt-1">Edi\xE7\xE3o \${data.edition.edition_number} - \${data.edition.year}</p>
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-3 text-sm mt-3 pt-3 border-t border-green-200">
                                <div>
                                    <p class="font-semibold">Publicado em:</p>
                                    <p>\${new Date(data.edition.published_at).toLocaleDateString('pt-BR')}</p>
                                </div>
                                <div>
                                    <p class="font-semibold">Total de Mat\xE9rias:</p>
                                    <p>\${data.edition.matter_count}</p>
                                </div>
                            </div>
                        </div>
                    \`;
                } else {
                    resultDiv.innerHTML = \`
                        <div class="bg-red-100 border-2 border-red-300 text-red-800 px-4 py-4 rounded-lg">
                            <div class="flex items-start">
                                <i class="fas fa-times-circle text-3xl mr-3 mt-1"></i>
                                <div>
                                    <p class="font-bold text-lg">\${data.message}</p>
                                    <p class="text-sm mt-1">O documento pode ter sido adulterado</p>
                                </div>
                            </div>
                        </div>
                    \`;
                }
            } catch (error) {
                resultDiv.innerHTML = \`
                    <div class="bg-red-100 border-2 border-red-300 text-red-800 px-4 py-3 rounded-lg">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        \${error.response?.data?.error || 'Erro ao verificar edi\xE7\xE3o'}
                    </div>
                \`;
            }
        }
        
        async function verifySignature() {
            const matterId = document.getElementById('matterId').value;
            const signatureHash = document.getElementById('signatureHash').value.trim();
            const resultDiv = document.getElementById('signatureResult');
            
            if (!matterId || !signatureHash) {
                resultDiv.innerHTML = \`
                    <div class="bg-red-100 border-2 border-red-300 text-red-800 px-4 py-3 rounded-lg">
                        <i class="fas fa-exclamation-triangle mr-2"></i>Preencha todos os campos
                    </div>
                \`;
                return;
            }
            
            resultDiv.innerHTML = \`
                <div class="bg-gray-100 border-2 border-gray-300 text-gray-800 px-4 py-3 rounded-lg">
                    <i class="fas fa-spinner fa-spin mr-2"></i>Verificando...
                </div>
            \`;
            
            try {
                const { data } = await axios.post('/api/verification/matter-signature', {
                    matter_id: parseInt(matterId),
                    signature_hash: signatureHash
                });
                
                if (data.valid) {
                    resultDiv.innerHTML = \`
                        <div class="result-valid bg-green-100 border-2 border-green-300 text-green-800 px-4 py-4 rounded-lg">
                            <div class="flex items-start mb-3">
                                <i class="fas fa-check-circle text-3xl mr-3 mt-1"></i>
                                <div>
                                    <p class="font-bold text-lg">\${data.message}</p>
                                    <p class="text-sm mt-1">\${data.matter.title}</p>
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-3 text-sm mt-3 pt-3 border-t border-green-200">
                                <div>
                                    <p class="font-semibold">Secretaria:</p>
                                    <p>\${data.matter.secretaria}</p>
                                </div>
                                <div>
                                    <p class="font-semibold">Assinado por:</p>
                                    <p>\${data.matter.signed_by}</p>
                                </div>
                            </div>
                        </div>
                    \`;
                } else {
                    resultDiv.innerHTML = \`
                        <div class="bg-red-100 border-2 border-red-300 text-red-800 px-4 py-4 rounded-lg">
                            <div class="flex items-start">
                                <i class="fas fa-times-circle text-3xl mr-3 mt-1"></i>
                                <div>
                                    <p class="font-bold text-lg">\${data.message}</p>
                                    <p class="text-sm mt-1">A assinatura pode ser inv\xE1lida</p>
                                </div>
                            </div>
                        </div>
                    \`;
                }
            } catch (error) {
                resultDiv.innerHTML = \`
                    <div class="bg-red-100 border-2 border-red-300 text-red-800 px-4 py-3 rounded-lg">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        \${error.response?.data?.error || 'Erro ao verificar assinatura'}
                    </div>
                \`;
            }
        }
    <\/script>
</body>
</html>
  `));
R.get("/", (e) => e.html(`
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOM - Di\xE1rio Oficial Municipal</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .sidebar {
            transition: transform 0.3s ease-in-out;
        }
        @media (max-width: 768px) {
            .sidebar.hidden {
                transform: translateX(-100%);
            }
        }
        
        /* WebGL Canvas Background */
        #webgl-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }
        
        .login-container {
            position: relative;
            z-index: 10;
        }
        
        .login-card {
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        
        .logo-pulse {
            animation: pulse 2s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        .gradient-text {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-link {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }
        
        .footer-link:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }
    </style>
</head>
<body class="bg-gray-50">
    <div id="app">
        <!-- Login Screen with WebGL Background -->
        <div id="loginScreen" class="min-h-screen flex flex-col items-center justify-center px-4">
            <!-- WebGL Canvas -->
            <canvas id="webgl-background"></canvas>
            
            <!-- Login Card -->
            <div class="login-container login-card rounded-2xl shadow-2xl p-8 w-full max-w-md">
                <div class="text-center mb-8">
                    <div class="bg-gradient-to-br from-blue-600 to-purple-600 w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center logo-pulse shadow-lg">
                        <i class="fas fa-newspaper text-white text-4xl"></i>
                    </div>
                    <h1 class="text-4xl font-bold gradient-text mb-2">DOM</h1>
                    <p class="text-gray-600 text-lg">Di\xE1rio Oficial Municipal</p>
                    <p class="text-gray-500 text-sm mt-1">S\xE3o Lu\xEDs - MA</p>
                </div>
                
                <form id="loginForm" class="space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-envelope mr-2"></i>Email
                        </label>
                        <input 
                            type="email" 
                            id="loginEmail" 
                            required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="seu@email.gov.br"
                        >
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-lock mr-2"></i>Senha
                        </label>
                        <input 
                            type="password" 
                            id="loginPassword" 
                            required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
                        >
                    </div>
                    
                    <button 
                        type="submit"
                        class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition duration-200"
                    >
                        <i class="fas fa-sign-in-alt mr-2"></i>Entrar
                    </button>
                    
                    <div class="text-center mt-3">
                        <button 
                            type="button"
                            id="forgotPasswordLink"
                            class="text-sm text-blue-600 hover:text-blue-800 hover:underline"
                        >
                            Esqueceu a senha?
                        </button>
                    </div>
                </form>
                
                <div id="loginError" class="mt-4 p-3 bg-red-50 border border-red-200 text-red-600 text-sm text-center rounded-lg hidden"></div>
                <div id="loginSuccess" class="mt-4 p-3 bg-green-50 border border-green-200 text-green-600 text-sm text-center rounded-lg hidden"></div>
                
                <div class="mt-8 text-center text-sm text-gray-600 bg-gray-50 rounded-lg p-4">
                    <p class="font-semibold text-gray-700 mb-2">Credenciais de teste:</p>
                    <p class="mt-1"><strong>Admin:</strong> admin@municipio.gov.br / admin123</p>
                    <p><strong>SEMAD:</strong> coordenador@semad.gov.br / semad123</p>
                    <p><strong>Secretaria:</strong> joao.silva@semed.gov.br / secretaria123</p>
                </div>
            </div>
            
            <!-- Footer with Prefeitura Link -->
            <div class="login-container mt-8 text-center space-y-4">
                <!-- Link Portal P\xFAblico -->
                <a href="/portal" class="footer-link inline-flex items-center space-x-2 text-white font-bold text-lg bg-blue-600 bg-opacity-20 px-6 py-3 rounded-lg hover:bg-opacity-30 transition">
                    <i class="fas fa-book-open"></i>
                    <span>Portal do Di\xE1rio Oficial</span>
                    <i class="fas fa-arrow-right text-sm"></i>
                </a>
                
                <!-- Link Verificar Autenticidade (P\xDABLICO) -->
                <a href="/verificar" class="footer-link inline-flex items-center space-x-2 text-white font-bold text-lg bg-purple-600 bg-opacity-20 px-6 py-3 rounded-lg hover:bg-opacity-30 transition">
                    <i class="fas fa-shield-alt"></i>
                    <span>Verificar Autenticidade do Di\xE1rio</span>
                    <i class="fas fa-arrow-right text-sm"></i>
                </a>
                
                <div class="flex justify-center space-x-6">
                    <a href="https://www.saoluis.ma.gov.br" target="_blank" rel="noopener noreferrer" class="footer-link inline-flex items-center space-x-2 text-white font-medium hover:text-blue-200 transition">
                        <i class="fas fa-landmark"></i>
                        <span>Portal da Prefeitura</span>
                        <i class="fas fa-external-link-alt text-sm"></i>
                    </a>
                </div>
                
                <p class="text-white text-sm opacity-80">
                    \xA9 2025 Prefeitura Municipal de S\xE3o Lu\xEDs - MA
                </p>
            </div>
        </div>
        
        <!-- Main Dashboard (hidden initially) -->
        <div id="dashboardScreen" class="hidden">
            <!-- Top Navigation Bar - FIXED -->
            <nav class="bg-white shadow-lg border-b border-gray-200 fixed top-0 left-0 right-0 z-50">
                <div class="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between h-16">
                        <div class="flex items-center">
                            <button id="toggleSidebar" class="mr-4 text-gray-600 hover:text-gray-800 md:hidden">
                                <i class="fas fa-bars text-xl"></i>
                            </button>
                            <div class="flex items-center">
                                <div class="bg-blue-600 w-10 h-10 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-newspaper text-white"></i>
                                </div>
                                <div class="ml-3">
                                    <h1 class="text-xl font-bold text-gray-800">DOM</h1>
                                    <p class="text-xs text-gray-500">Di\xE1rio Oficial</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="flex items-center space-x-4">
                            <a href="/portal" target="_blank" class="text-blue-600 hover:text-blue-800 font-medium transition">
                                <i class="fas fa-book-open mr-2"></i>Portal P\xFAblico
                            </a>
                            
                            <button id="notificationBtn" class="text-gray-600 hover:text-gray-800 relative">
                                <i class="fas fa-bell text-xl"></i>
                                <span id="notificationBadge" class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center hidden">0</span>
                            </button>
                            
                            <div class="flex items-center space-x-3">
                                <div class="text-right hidden sm:block">
                                    <p id="userName" class="text-sm font-semibold text-gray-800"></p>
                                    <p id="userRole" class="text-xs text-gray-500"></p>
                                </div>
                                <button id="logoutBtn" class="bg-red-50 hover:bg-red-100 text-red-600 px-4 py-2 rounded-lg text-sm font-medium transition">
                                    <i class="fas fa-sign-out-alt mr-2"></i>Sair
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            
            <div class="flex h-screen overflow-hidden pt-16">
                <!-- Sidebar - FIXED -->
                <aside id="sidebar" class="sidebar bg-white w-64 border-r border-gray-200 overflow-y-auto fixed left-0 top-16 bottom-0">
                    <nav class="p-4 space-y-2">
                        <a href="#" data-view="dashboard" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                            <i class="fas fa-chart-line w-6"></i>
                            <span class="ml-3">Dashboard</span>
                        </a>
                        
                        <div id="secretariaMenu" class="hidden">
                            <a href="#" data-view="myMatters" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-file-alt w-6"></i>
                                <span class="ml-3">Minhas Mat\xE9rias</span>
                            </a>
                            <a href="#" data-view="newMatter" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-plus-circle w-6"></i>
                                <span class="ml-3">Nova Mat\xE9ria</span>
                            </a>
                        </div>
                        
                        <div id="semadMenu" class="hidden">
                            <a href="#" data-view="pendingReview" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-tasks w-6"></i>
                                <span class="ml-3">Pendentes de An\xE1lise</span>
                            </a>
                            <a href="#" data-view="approved" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-check-circle w-6"></i>
                                <span class="ml-3">Aprovadas</span>
                            </a>
                        </div>
                        
                        <a href="#" data-view="search" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                            <i class="fas fa-search w-6"></i>
                            <span class="ml-3">Pesquisar</span>
                        </a>
                        
                        <div id="semadAdminMenu" class="hidden">
                            <a href="#" data-view="editions" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-book w-6"></i>
                                <span class="ml-3">Edi\xE7\xF5es do Di\xE1rio</span>
                            </a>
                        </div>
                        
                        <div id="adminMenu" class="hidden">
                            <a href="#" data-view="verification" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-shield-alt w-6"></i>
                                <span class="ml-3">Verificar Autenticidade</span>
                            </a>
                            <a href="#" data-view="users" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-users w-6"></i>
                                <span class="ml-3">Usu\xE1rios</span>
                            </a>
                            <a href="#" data-view="secretarias" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-building w-6"></i>
                                <span class="ml-3">Secretarias</span>
                            </a>
                            <a href="#" data-view="holidays" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-calendar-alt w-6"></i>
                                <span class="ml-3">Feriados</span>
                            </a>
                            <a href="#" data-view="settings" class="nav-link flex items-center px-4 py-3 text-gray-700 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition">
                                <i class="fas fa-cog w-6"></i>
                                <span class="ml-3">Configura\xE7\xF5es</span>
                            </a>
                        </div>
                    </nav>
                </aside>
                
                <!-- Main Content -->
                <main class="flex-1 overflow-y-auto bg-gray-50 p-6 ml-64">
                    <div id="mainContent">
                        <div class="text-center py-12">
                            <i class="fas fa-spinner fa-spin text-4xl text-blue-600"></i>
                            <p class="mt-4 text-gray-600">Carregando...</p>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"><\/script>
    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"><\/script>
    <script src="/static/webgl-init.js"><\/script>
    <script src="/static/app.js"><\/script>
</body>
</html>
  `));
R.get("/pesquisa", (e) => e.html(`
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa - DOM</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h1 class="text-3xl font-bold text-gray-800 mb-4">
                <i class="fas fa-search mr-3 text-blue-600"></i>
                Pesquisa de Publica\xE7\xF5es
            </h1>
            <p class="text-gray-600">Pesquise publica\xE7\xF5es do Di\xE1rio Oficial Municipal</p>
        </div>
        
        <div class="bg-white rounded-lg shadow-lg p-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <input 
                    type="text" 
                    id="searchQuery"
                    class="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="Buscar por t\xEDtulo ou conte\xFAdo..."
                >
                
                <input 
                    type="date" 
                    id="searchDate"
                    class="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                
                <button 
                    id="searchBtn"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition"
                >
                    <i class="fas fa-search mr-2"></i>Pesquisar
                </button>
            </div>
            
            <div id="searchResults" class="space-y-4">
                <p class="text-gray-500 text-center py-8">Digite algo para pesquisar...</p>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"><\/script>
    <script src="/static/search.js"><\/script>
</body>
</html>
  `));
R.get("/portal", (e) => e.html(`
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal do Di\xE1rio Oficial - S\xE3o Lu\xEDs</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            overflow-x: hidden;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }
        
        /* WebGL Canvas Background */
        #webgl-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }
        
        .portal-container {
            position: relative;
            z-index: 1;
        }
        
        .portal-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        
        .hover-lift {
            transition: all 0.3s ease;
        }
        
        .hover-lift:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
        }
        
        .gradient-text {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 min-h-screen">
    <!-- WebGL Canvas -->
    <canvas id="webgl-background"></canvas>
    
    <!-- Navbar -->
    <nav class="portal-container bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg border-b border-white border-opacity-20 py-4">
        <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <div class="flex items-center space-x-3">
                <i class="fas fa-newspaper text-white text-3xl"></i>
                <div>
                    <h1 class="text-white text-xl font-bold">Portal do Di\xE1rio Oficial</h1>
                    <p class="text-blue-200 text-sm">S\xE3o Lu\xEDs - MA</p>
                </div>
            </div>
            <div class="flex space-x-4">
                <a href="/portal" class="text-white hover:text-blue-200 transition">
                    <i class="fas fa-home mr-2"></i>In\xEDcio
                </a>
                <a href="/verificar" class="text-white hover:text-blue-200 transition">
                    <i class="fas fa-shield-alt mr-2"></i>Verificar
                </a>
                <a href="/" class="text-white hover:text-blue-200 transition">
                    <i class="fas fa-sign-in-alt mr-2"></i>\xC1rea Restrita
                </a>
            </div>
        </div>
    </nav>
    
    <!-- Main Content -->
    <div class="portal-container max-w-7xl mx-auto px-4 py-12">
        <!-- Hero Section -->
        <div class="text-center mb-12">
            <div class="inline-block bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg rounded-full p-6 mb-6">
                <i class="fas fa-book-open text-white text-6xl"></i>
            </div>
            <h2 class="text-4xl font-bold text-white mb-4">Publica\xE7\xF5es Oficiais</h2>
            <p class="text-blue-200 text-lg max-w-2xl mx-auto">
                Consulte as edi\xE7\xF5es do Di\xE1rio Oficial Municipal de S\xE3o Lu\xEDs
            </p>
        </div>
        
        <!-- Search Bar -->
        <div class="portal-card rounded-2xl p-6 mb-8">
            <div class="flex gap-4">
                <div class="flex-1">
                    <input 
                        type="text" 
                        id="portalSearch"
                        class="w-full px-6 py-4 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition text-lg"
                        placeholder="Pesquisar publica\xE7\xF5es..."
                    >
                </div>
                <button 
                    onclick="searchPortal()"
                    class="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold px-8 py-4 rounded-xl transition transform hover:scale-105"
                >
                    <i class="fas fa-search mr-2"></i>Buscar
                </button>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div class="portal-card rounded-2xl p-6 hover-lift cursor-pointer">
                <div class="flex items-center justify-between mb-4">
                    <div class="bg-blue-100 rounded-full p-4">
                        <i class="fas fa-book text-blue-600 text-2xl"></i>
                    </div>
                    <span id="totalEditions" class="text-4xl font-bold text-blue-600">0</span>
                </div>
                <h3 class="text-lg font-semibold text-gray-800">Edi\xE7\xF5es Publicadas</h3>
                <p class="text-sm text-gray-500 mt-1">Total de edi\xE7\xF5es dispon\xEDveis</p>
            </div>
            
            <div class="portal-card rounded-2xl p-6 hover-lift cursor-pointer">
                <div class="flex items-center justify-between mb-4">
                    <div class="bg-green-100 rounded-full p-4">
                        <i class="fas fa-file-alt text-green-600 text-2xl"></i>
                    </div>
                    <span id="totalMatters" class="text-4xl font-bold text-green-600">0</span>
                </div>
                <h3 class="text-lg font-semibold text-gray-800">Mat\xE9rias Publicadas</h3>
                <p class="text-sm text-gray-500 mt-1">Total de documentos</p>
            </div>
            
            <div class="portal-card rounded-2xl p-6 hover-lift cursor-pointer">
                <div class="flex items-center justify-between mb-4">
                    <div class="bg-purple-100 rounded-full p-4">
                        <i class="fas fa-calendar text-purple-600 text-2xl"></i>
                    </div>
                    <span id="thisMonth" class="text-4xl font-bold text-purple-600">0</span>
                </div>
                <h3 class="text-lg font-semibold text-gray-800">Este M\xEAs</h3>
                <p class="text-sm text-gray-500 mt-1">Publica\xE7\xF5es recentes</p>
            </div>
        </div>
        
        <!-- Analytics Charts -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div class="portal-card rounded-2xl p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4">
                    <i class="fas fa-chart-pie mr-2 text-purple-600"></i>
                    Publica\xE7\xF5es por Secretaria
                </h3>
                <canvas id="chartBySecretaria" style="max-height: 300px;"></canvas>
            </div>
            
            <div class="portal-card rounded-2xl p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4">
                    <i class="fas fa-chart-bar mr-2 text-green-600"></i>
                    Tipos de Mat\xE9ria
                </h3>
                <canvas id="chartByType" style="max-height: 300px;"></canvas>
            </div>
        </div>
        
        <!-- Latest Editions -->
        <div class="portal-card rounded-2xl p-8 mb-8">
            <h3 class="text-2xl font-bold text-gray-800 mb-6">
                <i class="fas fa-newspaper mr-3 text-blue-600"></i>
                \xDAltimas Edi\xE7\xF5es
            </h3>
            <div id="latestEditions" class="space-y-4">
                <div class="text-center py-8">
                    <i class="fas fa-spinner fa-spin text-4xl text-blue-600"></i>
                    <p class="mt-4 text-gray-600">Carregando...</p>
                </div>
            </div>
        </div>
        
        <!-- Most Searched Words (Word Cloud Style) -->
        <div class="portal-card rounded-2xl p-8">
            <h3 class="text-2xl font-bold text-gray-800 mb-6">
                <i class="fas fa-fire mr-3 text-orange-600"></i>
                Termos Mais Buscados
            </h3>
            <div id="mostSearched" class="flex flex-wrap gap-3 justify-center">
                <!-- Ser\xE1 preenchido dinamicamente com tamanhos variados -->
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="portal-container text-center py-8 text-white text-sm mt-12">
        <p class="mb-2">\xA9 2025 Prefeitura Municipal de S\xE3o Lu\xEDs - MA</p>
        <p class="text-blue-200">Sistema Oficial de Publica\xE7\xF5es | Todos os direitos reservados</p>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"><\/script>
    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"><\/script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"><\/script>
    <script src="/static/webgl-init.js"><\/script>
    <script>
        // Load portal data
        async function loadPortalData() {
            try {
                // Load stats
                const statsResponse = await axios.get('/api/portal/stats');
                document.getElementById('totalEditions').textContent = statsResponse.data.total_editions || 0;
                document.getElementById('totalMatters').textContent = statsResponse.data.total_matters || 0;
                document.getElementById('thisMonth').textContent = statsResponse.data.this_month || 0;
                
                // Load analytics for charts
                const analyticsResponse = await axios.get('/api/portal/analytics');
                renderCharts(analyticsResponse.data);
                
                // Load latest editions
                const editionsResponse = await axios.get('/api/portal/editions');
                renderLatestEditions(editionsResponse.data.editions || []);
                
                // Load most searched words
                const searchResponse = await axios.get('/api/portal/most-searched');
                renderMostSearched(searchResponse.data.terms || []);
                
            } catch (error) {
                console.error('Error loading portal data:', error);
                document.getElementById('latestEditions').innerHTML = \`
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-exclamation-triangle text-4xl mb-4"></i>
                        <p>Erro ao carregar dados</p>
                    </div>
                \`;
            }
        }
        
        function renderCharts(data) {
            // Chart: Publica\xE7\xF5es por Secretaria
            const ctxSec = document.getElementById('chartBySecretaria');
            if (ctxSec && data.by_secretaria) {
                new Chart(ctxSec, {
                    type: 'doughnut',
                    data: {
                        labels: data.by_secretaria.map(s => s.acronym || s.name),
                        datasets: [{
                            data: data.by_secretaria.map(s => s.count),
                            backgroundColor: [
                                '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b',
                                '#10b981', '#06b6d4', '#6366f1', '#84cc16'
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'bottom' }
                        }
                    }
                });
            }
            
            // Chart: Tipos de Mat\xE9ria
            const ctxType = document.getElementById('chartByType');
            if (ctxType && data.by_type) {
                new Chart(ctxType, {
                    type: 'bar',
                    data: {
                        labels: data.by_type.map(t => t.name),
                        datasets: [{
                            label: 'Quantidade',
                            data: data.by_type.map(t => t.count),
                            backgroundColor: '#10b981'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false }
                        },
                        scales: {
                            y: { beginAtZero: true }
                        }
                    }
                });
            }
        }
        
        function renderLatestEditions(editions) {
            if (editions.length === 0) {
                document.getElementById('latestEditions').innerHTML = \`
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-inbox text-4xl mb-4"></i>
                        <p>Nenhuma edi\xE7\xE3o publicada</p>
                    </div>
                \`;
                return;
            }
            
            document.getElementById('latestEditions').innerHTML = editions.map(edition => \`
                <div class="border border-gray-200 rounded-xl p-6 hover:bg-gray-50 transition cursor-pointer" onclick="viewEditionPortal(\${edition.id})">
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <div class="flex items-center gap-3 mb-2">
                                <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                                    Edi\xE7\xE3o \${edition.edition_number}
                                </span>
                                \${edition.is_supplemental ? '<span class="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-xs font-medium">SUPLEMENTAR</span>' : ''}
                            </div>
                            <h4 class="text-lg font-semibold text-gray-900 mb-2">
                                Di\xE1rio Oficial - \${edition.year}
                            </h4>
                            <p class="text-sm text-gray-600">
                                <i class="fas fa-calendar mr-2"></i>
                                \${new Date(edition.edition_date).toLocaleDateString('pt-BR')}
                            </p>
                            <p class="text-sm text-gray-600 mt-1">
                                <i class="fas fa-file-alt mr-2"></i>
                                \${edition.matter_count || 0} mat\xE9ria(s)
                            </p>
                        </div>
                        <a 
                            href="/api/editions/\${edition.id}/pdf" 
                            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition"
                            onclick="event.stopPropagation()"
                        >
                            <i class="fas fa-download mr-2"></i>Baixar
                        </a>
                    </div>
                </div>
            \`).join('');
        }
        
        function renderMostSearched(terms) {
            if (!terms || terms.length === 0) {
                terms = [
                    { term: 'Decreto', count: 156 },
                    { term: 'Portaria', count: 134 },
                    { term: 'Edital', count: 98 },
                    { term: 'Licita\xE7\xE3o', count: 87 },
                    { term: 'Concurso', count: 76 },
                    { term: 'Contrato', count: 65 },
                    { term: 'Nomea\xE7\xE3o', count: 54 },
                    { term: 'Exonera\xE7\xE3o', count: 43 }
                ];
            }
            
            // Word cloud style - tamanhos proporcionais \xE0 contagem
            const maxCount = Math.max(...terms.map(t => t.count));
            const colors = ['orange', 'red', 'purple', 'blue', 'green', 'pink', 'indigo', 'yellow'];
            
            document.getElementById('mostSearched').innerHTML = terms.map((item, index) => {
                const size = Math.max(0.8, (item.count / maxCount));
                const fontSize = 0.8 + (size * 1.2); // 0.8rem to 2rem
                const color = colors[index % colors.length];
                
                return \`
                    <button 
                        onclick="quickSearch('\${item.term}')"
                        class="bg-gradient-to-r from-\${color}-100 to-\${color}-200 hover:from-\${color}-200 hover:to-\${color}-300 text-gray-800 px-4 py-2 rounded-full font-medium transition transform hover:scale-110"
                        style="font-size: \${fontSize}rem;"
                        title="\${item.count} buscas"
                    >
                        <i class="fas fa-search mr-1"></i>\${item.term}
                    </button>
                \`;
            }).join('');
        }
        
        function searchPortal() {
            const query = document.getElementById('portalSearch').value;
            if (query) {
                window.location.href = \`/pesquisa?q=\${encodeURIComponent(query)}\`;
            }
        }
        
        function quickSearch(term) {
            window.location.href = \`/pesquisa?q=\${encodeURIComponent(term)}\`;
        }
        
        function viewEditionPortal(id) {
            window.location.href = \`/api/editions/\${id}/pdf\`;
        }
        
        // Load data on page load
        loadPortalData();
    <\/script>
</body>
</html>
  `));
R.notFound((e) => e.json({ error: "Rota n\xE3o encontrada" }, 404));
R.onError((e, t) => (console.error("Application error:", e), t.json({ error: "Erro interno do servidor", details: e.message }, 500)));
var it = new C();
var Br = Object.assign({ "/src/index.tsx": R });
var Ft = false;
for (const [, e] of Object.entries(Br)) e && (it.all("*", (t) => {
  let r;
  try {
    r = t.executionCtx;
  } catch {
  }
  return e.fetch(t.req.raw, t.env, r);
}), it.notFound((t) => {
  let r;
  try {
    r = t.executionCtx;
  } catch {
  }
  return e.fetch(t.req.raw, t.env, r);
}), Ft = true);
if (!Ft) throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");

// ../node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody = /* @__PURE__ */ __name(async (request, env2, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env2);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;

// ../node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name(async (request, env2, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env2);
  } catch (e) {
    const error3 = reduceError(e);
    return Response.json(error3, {
      status: 500,
      headers: { "MF-Experimental-Error-Stack": "true" }
    });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;

// ../.wrangler/tmp/bundle-4sGYBf/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = it;

// ../node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env2, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env2, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env2, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env2, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");

// ../.wrangler/tmp/bundle-4sGYBf/middleware-loader.entry.ts
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env2, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env2, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env2, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env2, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env2, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env2, ctx) => {
      this.env = env2;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default as default
};
//# sourceMappingURL=bundledWorker-0.43860840892381003.mjs.map
