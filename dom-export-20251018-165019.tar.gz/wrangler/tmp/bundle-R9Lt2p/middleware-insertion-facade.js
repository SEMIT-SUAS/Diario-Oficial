				import worker, * as OTHER_EXPORTS from "/home/user/dom/.wrangler/tmp/pages-KXbI2d/136965iz0bbi.js";
				import * as __MIDDLEWARE_0__ from "/home/user/dom/node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts";
import * as __MIDDLEWARE_1__ from "/home/user/dom/node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts";

				export * from "/home/user/dom/.wrangler/tmp/pages-KXbI2d/136965iz0bbi.js";
				const MIDDLEWARE_TEST_INJECT = "__INJECT_FOR_TESTING_WRANGLER_MIDDLEWARE__";
				export const __INTERNAL_WRANGLER_MIDDLEWARE__ = [
					
					__MIDDLEWARE_0__.default,__MIDDLEWARE_1__.default
				]
				export default worker;